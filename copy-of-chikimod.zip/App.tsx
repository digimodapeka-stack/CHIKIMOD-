
import React, { useState, useEffect } from 'react';
import { NavItem, User, Rank, AppNotification, Report, AppData } from './types';
import { MOCK_USERS as INITIAL_USERS, MOCK_REPORTS as INITIAL_REPORTS, MOCK_APPS as INITIAL_APPS } from './constants';
import Store from './components/Store';
import Leaderboard from './components/Leaderboard';
import AIChat from './components/AIChat';
import Admin from './components/Admin';
import Profile from './components/Profile';
import NotificationCenter from './components/NotificationCenter';
import CommunityChat from './components/CommunityChat';
import Forum from './components/Forum';
import ToolsHub from './components/ToolsHub';
import VipPlusHub from './components/VipPlusHub';
import About from './components/About';
import SplashScreen from './components/SplashScreen';
import GenZPopups from './components/GenZPopups';

const SnowEffect = () => {
  const [flakes, setFlakes] = useState<any[]>([]);
  useEffect(() => {
    const newFlakes = Array.from({ length: 50 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100 + '%',
      duration: 5 + Math.random() * 10 + 's',
      delay: Math.random() * 5 + 's',
      opacity: 0.3 + Math.random() * 0.7,
      size: 5 + Math.random() * 15 + 'px'
    }));
    setFlakes(newFlakes);
  }, []);

  return (
    <div className="snow-container">
      {flakes.map(f => (
        <div key={f.id} className="snowflake" style={{ 
          left: f.left, 
          animationDuration: f.duration, 
          animationDelay: f.delay, 
          opacity: f.opacity,
          fontSize: f.size
        }}>❄</div>
      ))}
    </div>
  );
};

const LightningEffect = () => {
  const [flash, setFlash] = useState(false);
  useEffect(() => {
    const trigger = () => {
      setFlash(true);
      setTimeout(() => setFlash(false), 200);
      setTimeout(trigger, 3000 + Math.random() * 7000);
    };
    const initialTimeout = setTimeout(trigger, 3000);
    return () => clearTimeout(initialTimeout);
  }, []);

  return <div className={`lightning-flash ${flash ? 'flash-animate' : ''}`}></div>;
};

const App: React.FC = () => {
  const [appStage, setAppStage] = useState<'SPLASH' | 'POPUPS' | 'MAIN'>('SPLASH');
  const [activeTab, setActiveTab] = useState<NavItem>('STORE');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [weatherEffect, setWeatherEffect] = useState<'NONE' | 'SNOW' | 'LIGHTNING'>('NONE');
  const [manualFlash, setManualFlash] = useState(false);
  const [wobbleKey, setWobbleKey] = useState<string | null>(null);
  
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [apps, setApps] = useState<AppData[]>(INITIAL_APPS);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [reports, setReports] = useState<Report[]>(INITIAL_REPORTS);

  useEffect(() => {
    (window as any).currentUser = currentUser;
  }, [currentUser]);

  const handleLogin = (email: string) => {
    const existingUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (existingUser) {
      const today = new Date().toISOString().split('T')[0];
      let newStreak = existingUser.streakCount;
      if (existingUser.lastActiveDate !== today) {
        newStreak += 1;
      }
      const updatedUser = { ...existingUser, streakCount: newStreak, lastActiveDate: today };
      setCurrentUser(updatedUser);
      setIsLoggedIn(true);
    } else {
      const newUser: User = {
        id: 'u' + Date.now(),
        name: email.split('@')[0],
        email: email,
        rank: Rank.BRONZE,
        points: 100,
        isVIP: false,
        isPLUS: false,
        isAdmin: email === 'ifgaralviyansah71@gmail.com',
        avatar: `https://picsum.photos/seed/${email}/100`,
        privacy: { 
          showActivity: true, 
          privateProfile: false, 
          showRank: true, 
          publicDownloads: true,
          showSocials: true,
          allowMessages: true
        },
        notificationPreferences: {
          comments: true,
          updates: true,
          system: true,
          messages: true,
          vip: true,
        },
        socials: { instagram: '', github: '', discord: '', twitter: '', telegram: '' },
        streakCount: 1,
        lastActiveDate: new Date().toISOString().split('T')[0],
        coupleFlowerLevel: 0,
        tag: Math.floor(1000 + Math.random() * 9000).toString()
      };
      setUsers(prev => [...prev, newUser]);
      setCurrentUser(newUser);
      setIsLoggedIn(true);
    }
    addNotification('Sistem Sinkron', 'Node lo berhasil terhubung ke Cluster CHIKIMOD.', 'SYSTEM');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
  };

  const addNotification = (title: string, message: string, type: AppNotification['type']) => {
    if (currentUser) {
      const prefs = currentUser.notificationPreferences;
      let allowed = true;
      if (type === 'COMMENT') allowed = prefs.comments;
      if (type === 'UPDATE') allowed = prefs.updates;
      if (type === 'SYSTEM' || type === 'STREAK') allowed = prefs.system;
      if (type === 'MESSAGE') allowed = prefs.messages;
      if (type === 'VIP') allowed = prefs.vip;
      if (!allowed) return;
    }

    const newNotif: AppNotification = {
      id: Date.now().toString(),
      title,
      message,
      type,
      timestamp: 'Sekarang',
      read: false
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const addPoints = (amount: number) => {
    if (!currentUser) return;
    setCurrentUser(prev => {
        if (!prev) return null;
        const updated = { ...prev, points: prev.points + amount };
        checkRankUp(updated);
        return updated;
    });
  };

  const checkRankUp = (user: User) => {
    let newRank = user.rank;
    if (user.points >= 10000) newRank = Rank.GRANDMASTER;
    else if (user.points >= 8000) newRank = Rank.MASTER;
    else if (user.points >= 5000) newRank = Rank.DIAMOND;
    else if (user.points >= 3000) newRank = Rank.PLATINUM;
    else if (user.points >= 1500) newRank = Rank.GOLD;
    else if (user.points >= 500) newRank = Rank.SILVER;
    else newRank = Rank.BRONZE;

    if (newRank !== user.rank) {
      setCurrentUser(prev => prev ? ({ ...prev, rank: newRank }) : null);
      addNotification('Evolusi Node!', `Rank lo naik ke ${newRank}! 🔥`, 'SYSTEM');
    }
  };

  const handleNavClick = (id: NavItem) => {
    setWobbleKey(id);
    setActiveTab(id);
    setTimeout(() => setWobbleKey(null), 500);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'STORE': return <Store 
        apps={apps}
        onAction={() => addPoints(10)} 
        onNotifyBellClick={() => setShowNotifications(!showNotifications)} 
        unreadCount={notifications.filter(n => !n.read).length} 
        onReport={() => {}} 
        isVIP={currentUser?.isVIP || false}
        onNavigate={(tab) => setActiveTab(tab)}
        isDarkMode={isDarkMode}
        user={currentUser || users[0]}
      />;
      case 'FORUM': return <Forum 
        onAction={() => addPoints(5)} 
        onNotifyBellClick={() => setShowNotifications(!showNotifications)} 
        unreadCount={notifications.filter(n => !n.read).length}
        onReport={() => {}}
        onSimulateNotification={addNotification}
      />;
      case 'COMMUNITY': return <CommunityChat currentUser={currentUser || users[0]} onAction={() => addPoints(5)} />;
      case 'LEADERBOARD': return <Leaderboard users={users} isDarkMode={isDarkMode} />;
      case 'TOOLS': return <ToolsHub isDarkMode={isDarkMode} isVIP={currentUser?.isVIP || false} onAction={() => addPoints(25)} />;
      case 'AI': return <AIChat />;
      case 'VIP_HUB': return <VipPlusHub user={currentUser || users[0]} onUpgrade={(type) => currentUser && setCurrentUser({...currentUser, [type === 'VIP' ? 'isVIP' : 'isPLUS']: true})} isDarkMode={isDarkMode} />;
      case 'ABOUT': return <About isDarkMode={isDarkMode} />;
      case 'PROFILE': return (
        <Profile 
          isLoggedIn={isLoggedIn}
          onLogin={handleLogin}
          onLogout={handleLogout}
          user={currentUser} 
          onAdminToggle={() => setActiveTab('ADMIN')} 
          onUpdatePrivacy={() => {}} 
          onUpdateProfile={(data) => {
            if (!currentUser) return;
            const updated = {...currentUser, ...data};
            setCurrentUser(updated);
            setUsers(prev => prev.map(u => u.id === updated.id ? updated : u));
          }} 
          isDarkMode={isDarkMode} 
          onAddPoints={addPoints} 
          onAddNotification={addNotification} 
        />
      );
      case 'ADMIN': return <Admin users={users} setUsers={setUsers} apps={apps} setApps={setApps} reports={reports} setReports={setReports} onSendGlobalNotification={addNotification} />;
      default: return null;
    }
  };

  const navItems = [
    { id: 'STORE', icon: 'fa-shopping-bag', label: 'Store' },
    { id: 'FORUM', icon: 'fa-earth-americas', label: 'Forum' },
    { id: 'COMMUNITY', icon: 'fa-message', label: 'Chat' },
    { id: 'VIP_HUB', icon: 'fa-gem', label: 'VIP/PLUS' },
    { id: 'LEADERBOARD', icon: 'fa-trophy', label: 'Rank' },
    { id: 'AI', icon: 'fa-robot', label: 'AI' },
    { id: 'PROFILE', icon: 'fa-user-circle', label: 'Me' },
  ];

  if (appStage === 'SPLASH') {
    return <SplashScreen onUnlock={() => setAppStage('POPUPS')} />;
  }

  if (appStage === 'POPUPS') {
    return (
      <div className={`max-w-4xl mx-auto min-h-screen relative shadow-2xl overflow-hidden flex flex-col transition-colors duration-500 ${isDarkMode ? 'bg-slate-950 text-white' : 'bg-[#fcfcfc] text-black'}`}>
        <GenZPopups onComplete={() => setAppStage('MAIN')} />
      </div>
    );
  }

  return (
    <div className={`max-w-4xl mx-auto min-h-screen relative shadow-2xl overflow-hidden flex flex-col transition-colors duration-500 ${isDarkMode ? 'bg-slate-950 text-white' : 'bg-[#fcfcfc] text-black'}`}>
      
      {weatherEffect === 'SNOW' && <SnowEffect />}
      {weatherEffect === 'LIGHTNING' && <LightningEffect />}
      {manualFlash && <div className="lightning-flash flash-animate"></div>}

      <div className="fixed top-24 right-8 z-[60] flex flex-col gap-4">
         <button onClick={() => setIsDarkMode(!isDarkMode)} title="Toggle Dark Mode" className={`w-14 h-14 rounded-2xl shadow-2xl flex items-center justify-center transition-all border-2 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-amber-400' : 'bg-white border-slate-100 text-black'}`}>
            <i className={`fa-solid ${isDarkMode ? 'fa-sun' : 'fa-moon'} text-xl`}></i>
         </button>
         <button 
            onClick={() => {
              const sequence: any[] = ['NONE', 'SNOW', 'LIGHTNING'];
              const next = sequence[(sequence.indexOf(weatherEffect) + 1) % sequence.length];
              setWeatherEffect(next);
            }} 
            className="w-14 h-14 rounded-2xl shadow-2xl flex items-center justify-center bg-black text-white border-2 border-white/10 transition-all hover:scale-110 active:scale-95"
          >
            <i className={`fa-solid ${weatherEffect === 'NONE' ? 'fa-wand-magic-sparkles' : weatherEffect === 'SNOW' ? 'fa-snowflake' : 'fa-bolt-lightning'} text-xl`}></i>
         </button>
      </div>

      {showNotifications && <NotificationCenter notifications={notifications} onClose={() => setShowNotifications(false)} onMarkRead={(id) => setNotifications(n => n.map(x => x.id === id ? {...x, read: true} : x))} onClearAll={() => setNotifications([])} />}
      
      <main className="flex-1 overflow-y-auto overflow-x-hidden relative custom-scrollbar">
        {renderContent()}
      </main>

      <nav className={`fixed bottom-0 left-0 right-0 max-w-4xl mx-auto border-t-[3px] px-2 py-4 z-50 flex justify-around items-end transition-colors duration-500 ${isDarkMode ? 'bg-slate-900/98 border-slate-800 backdrop-blur-3xl' : 'bg-white/98 border-slate-100 backdrop-blur-3xl'}`}>
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => handleNavClick(item.id as NavItem)}
            className={`flex flex-col items-center gap-1.5 flex-1 transition-all duration-300 relative ${
              activeTab === item.id 
              ? 'text-black -translate-y-2' 
              : (isDarkMode ? 'text-slate-500' : 'text-slate-300')
            }`}
          >
            <div className={`p-2.5 rounded-2xl transition-all ${wobbleKey === item.id ? 'animate-wobble' : ''} ${activeTab === item.id ? (isDarkMode ? 'bg-white/10' : 'bg-black text-white shadow-xl') : ''}`}>
              <i className={`fa-solid ${item.icon} text-xl`}></i>
            </div>
            <span className={`text-[8px] font-black uppercase tracking-widest`}>{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default App;
