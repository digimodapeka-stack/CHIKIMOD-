
import React, { useState, useRef, useEffect } from 'react';
import { chatWithAI } from '../services/gemini';

interface Message {
  role: 'user' | 'model';
  text: string;
}

const AIChat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Halo bro! Gue ChikiAI. Ada yang bisa gue bantu soal CHIKIMOD hari ini? Santai aja, tanya apa aja bebas.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    const response = await chatWithAI(userMsg, history);
    setMessages(prev => [...prev, { role: 'model', text: response || '' }]);
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50 pb-20">
      <div className="bg-white px-4 py-4 flex items-center gap-3 shadow-sm border-b border-gray-100">
        <div className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-white shadow-lg">
          <i className="fa-solid fa-face-smile-wink"></i>
        </div>
        <div>
          <h1 className="font-black text-gray-900 tracking-tight">ChikiAI <span className="text-[10px] bg-blue-600 text-white px-1.5 py-0.5 rounded-md ml-1">TEMEN LO</span></h1>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-[10px] text-gray-400 uppercase font-bold tracking-tighter">Lagi Online</span>
          </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-4 rounded-3xl text-sm leading-relaxed ${
              m.role === 'user' 
                ? 'bg-slate-900 text-white rounded-tr-none shadow-md' 
                : 'bg-white text-gray-800 shadow-sm border border-gray-100 rounded-tl-none'
            }`}>
              {m.text}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 rounded-tl-none animate-pulse flex gap-1.5 items-center">
              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-white border-t border-gray-100">
        <div className="flex gap-2 bg-gray-100 rounded-2xl px-4 py-2 items-center border border-gray-200 focus-within:border-blue-400 transition-all">
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Tanya apa aja bro..."
            className="flex-1 bg-transparent text-sm focus:outline-none py-2"
          />
          <button 
            onClick={handleSend}
            disabled={isLoading}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              input.trim() ? 'bg-blue-600 text-white shadow-lg shadow-blue-200 rotate-0' : 'bg-gray-300 text-gray-500 opacity-50'
            }`}
          >
            <i className="fa-solid fa-paper-plane text-xs"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIChat;
