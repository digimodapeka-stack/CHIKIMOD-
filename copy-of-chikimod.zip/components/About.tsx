
import React from 'react';

interface AboutProps {
  isDarkMode: boolean;
}

const About: React.FC<AboutProps> = ({ isDarkMode }) => {
  const textColor = isDarkMode ? 'text-white' : 'text-slate-900';
  const mutedText = isDarkMode ? 'text-slate-400' : 'text-slate-500';
  const cardBg = isDarkMode ? 'bg-slate-900/50' : 'bg-white';
  const borderColor = isDarkMode ? 'border-slate-800' : 'border-slate-100';

  return (
    <div className={`min-h-screen pb-32 pt-10 px-6 animate-in fade-in duration-700 ${isDarkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
      <header className="mb-12 text-center">
        <div className="w-20 h-20 bg-blue-600 rounded-[2rem] flex items-center justify-center text-white text-3xl mx-auto mb-6 shadow-2xl shadow-blue-500/20">
          <i className="fa-solid fa-bolt-lightning"></i>
        </div>
        <h1 className={`text-4xl font-black italic uppercase tracking-tighter ${textColor}`}>System Protocols</h1>
        <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em] mt-2">CHIKIMOD INFRASTRUCTURE v2.5</p>
      </header>

      <div className="space-y-8">
        {/* Mission Section */}
        <section className={`p-8 rounded-[3rem] border shadow-sm ${cardBg} ${borderColor} relative overflow-hidden`}>
          <div className="absolute -top-10 -right-10 opacity-5 pointer-events-none">
            <i className="fa-solid fa-earth-asia text-[15rem] text-blue-500"></i>
          </div>
          <h2 className="text-xs font-black text-blue-500 uppercase tracking-[0.3em] mb-4">Our Mission</h2>
          <p className={`text-sm font-medium leading-relaxed italic ${textColor}`}>
            "To provide a secure, community-driven ecosystem where premium technology is accessible to everyone. We believe in the power of modified software to enhance productivity, creativity, and entertainment."
          </p>
        </section>

        {/* Feature Grid */}
        <div className="grid grid-cols-2 gap-4">
          {[
            { title: 'Safe Node', icon: 'fa-shield-halved', color: 'text-emerald-500', desc: 'Sistem scan malware 3 lapis buat tiap upload.' },
            { title: 'Tiered Rank', icon: 'fa-trophy', color: 'text-amber-500', desc: 'Progresi XP nyata dari Bronze sampe Grandmaster.' },
            { title: 'AI Core', icon: 'fa-robot', color: 'text-purple-500', desc: 'Bantuan instan dari ChikiAI buat masalah mod lo.' },
            { title: 'Lounge Hub', icon: 'fa-message', color: 'text-blue-500', desc: 'Interaksi real-time tanpa delay antar user.' },
          ].map((feat, i) => (
            <div key={i} className={`p-6 rounded-[2.5rem] border shadow-sm flex flex-col items-center text-center ${cardBg} ${borderColor}`}>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-4 bg-white/5 ${feat.color}`}>
                <i className={`fa-solid ${feat.icon} text-xl`}></i>
              </div>
              <h3 className={`text-[11px] font-black uppercase tracking-tight mb-2 ${textColor}`}>{feat.title}</h3>
              <p className="text-[9px] font-medium text-slate-500 leading-tight">{feat.desc}</p>
            </div>
          ))}
        </div>

        {/* Developer Info */}
        <section className={`p-8 rounded-[3rem] border shadow-sm ${cardBg} ${borderColor}`}>
          <h2 className="text-xs font-black text-blue-500 uppercase tracking-[0.3em] mb-6">Development Team</h2>
          <div className="flex items-center gap-6">
            <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center text-white text-xl shadow-lg">
              <i className="fa-solid fa-code"></i>
            </div>
            <div>
              <h3 className={`text-sm font-black uppercase ${textColor}`}>CHIKIMOD Labs</h3>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Lead Architect: @ifgaralviyansah</p>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-slate-100 dark:border-slate-800">
            <p className="text-[10px] text-slate-400 font-medium leading-relaxed">
              Platform ini dibangun menggunakan teknologi enkripsi cluster terbaru untuk menjamin privasi node user tetap secure. Tetap asik, tetap aman, CHIKIMOD!
            </p>
          </div>
        </section>

        {/* Footer info */}
        <div className="text-center py-6">
          <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.5em]">Global Distributed System</p>
          <div className="flex justify-center gap-4 mt-4 text-slate-400 text-sm">
            <i className="fa-brands fa-github hover:text-blue-500 cursor-pointer"></i>
            <i className="fa-brands fa-discord hover:text-blue-500 cursor-pointer"></i>
            <i className="fa-brands fa-instagram hover:text-blue-500 cursor-pointer"></i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
