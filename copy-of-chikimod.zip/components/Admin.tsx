
import React, { useState, useEffect } from 'react';
import { AdminTab, Rank, User, Report, AppData, AppNotification } from '../types';
import RankBadge from './RankBadge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell } from 'recharts';

interface AdminProps {
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  apps: AppData[];
  setApps: React.Dispatch<React.SetStateAction<AppData[]>>;
  reports: Report[];
  setReports: React.Dispatch<React.SetStateAction<Report[]>>;
  onSendGlobalNotification: (title: string, msg: string, type: any) => void;
}

const Admin: React.FC<AdminProps> = ({ users, setUsers, apps, setApps, reports, setReports, onSendGlobalNotification }) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('DASHBOARD');
  const [deployProgress, setDeployProgress] = useState(0);
  const [isDeploying, setIsDeploying] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [maintenance, setMaintenance] = useState(false);
  
  // Forms States
  const [newApp, setNewApp] = useState({ name: '', category: 'Game', size: '', icon: '', description: '', isExclusive: 'NONE' as any, version: '1.0.0', developer: 'CHIKIMOD Labs' });
  const [signal, setSignal] = useState({ title: '', message: '', type: 'SYSTEM' as any });
  const [voucher, setVoucher] = useState({ code: '', reward: '1000 XP' });
  const [auditLogs, setAuditLogs] = useState<{id: string, action: string, time: string}[]>([
    { id: '1', action: 'Admin logged into control cluster', time: '10 mins ago' },
    { id: '2', action: 'Modified rank thresholds for Gold tier', time: '1 hour ago' }
  ]);

  const statsData = [
    { name: 'Mon', users: 400, apps: 240 },
    { name: 'Tue', users: 300, apps: 139 },
    { name: 'Wed', users: 500, apps: 980 },
    { name: 'Thu', users: 278, apps: 390 },
    { name: 'Fri', users: 600, apps: 480 },
    { name: 'Sat', users: 800, apps: 380 },
    { name: 'Sun', users: 950, apps: 430 },
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setNewApp(prev => ({ ...prev, size: (file.size / (1024 * 1024)).toFixed(1) + 'MB' }));
    }
  };

  const handleDeploy = () => {
    if (!newApp.name || !selectedFile) return;
    setIsDeploying(true);
    setDeployProgress(0);

    const interval = setInterval(() => {
      setDeployProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          return 100;
        }
        return p + Math.floor(Math.random() * 10) + 5;
      });
    }, 150);

    setTimeout(() => {
      const app: AppData = {
        id: Date.now().toString(),
        name: newApp.name,
        category: newApp.category,
        rating: 5.0,
        size: newApp.size,
        icon: newApp.icon || `https://picsum.photos/seed/${newApp.name}/200`,
        isModded: true,
        downloads: '0',
        description: newApp.description || 'Verified app uploaded by Admin.',
        isExclusive: newApp.isExclusive === 'NONE' ? undefined : newApp.isExclusive,
        version: newApp.version,
        developer: newApp.developer,
        fileUrl: URL.createObjectURL(selectedFile)
      };
      setApps([app, ...apps]);
      setIsDeploying(false);
      setDeployProgress(0);
      setSelectedFile(null);
      setNewApp({ name: '', category: 'Game', size: '', icon: '', description: '', isExclusive: 'NONE', version: '1.0.0', developer: 'CHIKIMOD Labs' });
      onSendGlobalNotification('Deployment Success', `${app.name} has been published.`, 'UPDATE');
      setAuditLogs([{id: Date.now().toString(), action: `Deployed ${app.name}`, time: 'Just now'}, ...auditLogs]);
    }, 3000);
  };

  const handleSendSignal = () => {
    if (!signal.title || !signal.message) return;
    onSendGlobalNotification(signal.title, signal.message, signal.type);
    setSignal({ title: '', message: '', type: 'SYSTEM' });
    setAuditLogs([{id: Date.now().toString(), action: `Sent Global Signal: ${signal.title}`, time: 'Just now'}, ...auditLogs]);
  };

  const handleResetDB = () => {
    if (confirm('Are you sure you want to reset all engagement metrics?')) {
      setApps(apps.map(a => ({ ...a, downloads: '0' })));
      setAuditLogs([{id: Date.now().toString(), action: 'Database Cleanup Executed', time: 'Just now'}, ...auditLogs]);
    }
  };

  const navItems: { id: AdminTab; label: string; icon: string }[] = [
    { id: 'DASHBOARD', label: 'Dashboard', icon: 'fa-chart-line' },
    { id: 'USERS', label: 'User Nodes', icon: 'fa-users-gear' },
    { id: 'APP_DEPLOY', label: 'App Deployer', icon: 'fa-cloud-arrow-up' },
    { id: 'SIGNALS', label: 'Signals', icon: 'fa-satellite-dish' },
    { id: 'MODERATION', label: 'Moderation', icon: 'fa-shield-halved' },
    { id: 'REPORTS', label: 'Reports Hub', icon: 'fa-flag' },
    { id: 'MAINTENANCE', label: 'Maintenance', icon: 'fa-screwdriver-wrench' },
    { id: 'VOUCHERS', label: 'Voucher Engine', icon: 'fa-ticket' },
    { id: 'SYSTEM_HEALTH', label: 'Sys Health', icon: 'fa-heart-pulse' },
    { id: 'AUDIT_LOGS', label: 'Audit Logs', icon: 'fa-receipt' },
    { id: 'BANNERS', label: 'Store Banners', icon: 'fa-images' },
    { id: 'API_KEYS', label: 'API Gateway', icon: 'fa-key' },
    { id: 'RANK_CONFIG', label: 'Rank Config', icon: 'fa-ranking-star' },
    { id: 'DATABASE', label: 'DB Tools', icon: 'fa-database' },
    { id: 'SUPPORT', label: 'Help Desk', icon: 'fa-headset' },
  ];

  const renderModule = () => {
    switch (activeTab) {
      case 'DASHBOARD':
        return (
          <div className="animate-in fade-in duration-700 space-y-10">
            <div className="grid grid-cols-4 gap-6">
              {[
                { l: 'Registered Nodes', v: users.length, i: 'fa-users', c: 'text-blue-500', bg: 'bg-blue-500/10' },
                { l: 'Network Traffic', v: '84.2 GB', i: 'fa-microchip', c: 'text-emerald-500', bg: 'bg-emerald-500/10' },
                { l: 'Stored Apps', v: apps.length, i: 'fa-box-open', c: 'text-purple-500', bg: 'bg-purple-500/10' },
                { l: 'Signal Strength', v: 'Excellent', i: 'fa-satellite-dish', c: 'text-amber-500', bg: 'bg-amber-500/10' },
              ].map((stat, i) => (
                <div key={i} className="bg-white/5 p-8 rounded-[3rem] border border-white/5 relative overflow-hidden group">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 ${stat.bg} ${stat.c} group-hover:scale-110 transition-transform`}>
                    <i className={`fa-solid ${stat.i} text-xl`}></i>
                  </div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2">{stat.l}</p>
                  <p className="text-3xl font-black text-white tracking-tighter">{stat.v}</p>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-8">
              <div className="bg-white/5 p-10 rounded-[3.5rem] border border-white/5 h-[400px]">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-8">User Acquisition Flow</h3>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={statsData}>
                    <defs>
                      <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '20px', color: '#fff' }} />
                    <Area type="monotone" dataKey="users" stroke="#3b82f6" strokeWidth={4} fillOpacity={1} fill="url(#colorUsers)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="bg-white/5 p-10 rounded-[3.5rem] border border-white/5 h-[400px]">
                 <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-8">System Resource Load</h3>
                 <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={statsData}>
                     <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '20px', color: '#fff' }} />
                     <Bar dataKey="apps" fill="#8b5cf6" radius={[10, 10, 0, 0]} />
                   </BarChart>
                 </ResponsiveContainer>
              </div>
            </div>
          </div>
        );
      case 'USERS':
        return (
          <div className="grid grid-cols-1 gap-4 animate-in slide-in-from-bottom-10 duration-500">
            {users.map(u => (
              <div key={u.id} className="bg-white/5 p-8 rounded-[3rem] border border-white/5 flex items-center justify-between group hover:bg-white/10 transition-all">
                 <div className="flex items-center gap-6">
                    <img src={u.avatar} className="w-16 h-16 rounded-[1.8rem] object-cover shadow-2xl border-2 border-white/5" />
                    <div>
                       <p className="text-lg font-black text-white italic tracking-tight">{u.name} <span className="text-slate-600 font-bold not-italic">#{u.tag}</span></p>
                       <div className="flex items-center gap-3 mt-1">
                          <RankBadge rank={u.rank} />
                          {u.isPLUS && <span className="text-[9px] bg-purple-500/20 text-purple-400 border border-purple-500/30 font-black px-3 py-0.5 rounded-full uppercase italic">PLUS NODE</span>}
                       </div>
                    </div>
                 </div>
                 <div className="flex gap-3">
                    <button className="px-6 py-3 bg-white/5 text-[10px] font-black uppercase text-slate-400 rounded-xl hover:bg-blue-600 hover:text-white transition-all">Grant VIP</button>
                    <button className="px-6 py-3 bg-red-500/10 text-[10px] font-black uppercase text-red-500 border border-red-500/20 rounded-xl hover:bg-red-500 hover:text-white transition-all">Terminate</button>
                 </div>
              </div>
            ))}
          </div>
        );
      case 'APP_DEPLOY':
        return (
          <div className="max-w-4xl animate-in zoom-in duration-500 bg-white/5 p-12 rounded-[4rem] border border-white/5 shadow-2xl">
            <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter mb-10 flex items-center gap-4">
               <i className="fa-solid fa-cloud-arrow-up text-blue-500"></i> Artifact Deployer
            </h3>
            <div className="space-y-6">
                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">App Identity</label>
                     <input value={newApp.name} onChange={e => setNewApp({...newApp, name: e.target.value})} className="w-full bg-[#020617] border border-white/5 rounded-3xl px-8 py-5 text-sm font-bold" placeholder="App Name..." />
                  </div>
                  <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Authorized Dev</label>
                     <input value={newApp.developer} onChange={e => setNewApp({...newApp, developer: e.target.value})} className="w-full bg-[#020617] border border-white/5 rounded-3xl px-8 py-5 text-sm font-bold" />
                  </div>
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Binary Archive (.apk, .zip)</label>
                   <input type="file" onChange={handleFileChange} className="w-full bg-[#020617] border border-dashed border-white/10 rounded-3xl px-8 py-10 text-xs font-black text-slate-500" />
                </div>
                {isDeploying && (
                  <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${deployProgress}%` }}></div>
                  </div>
                )}
                <button onClick={handleDeploy} disabled={isDeploying || !selectedFile} className="w-full py-6 bg-blue-600 text-white rounded-[2.5rem] font-black uppercase text-xs tracking-widest shadow-2xl hover:bg-blue-700 transition-all">
                   Initiate Push to CDN
                </button>
            </div>
          </div>
        );
      case 'SIGNALS':
        return (
          <div className="max-w-2xl bg-white/5 p-12 rounded-[4rem] border border-white/5 animate-in fade-in duration-500">
             <h3 className="text-xl font-black text-white italic uppercase tracking-tighter mb-10 flex items-center gap-4">
                <i className="fa-solid fa-satellite-dish text-amber-500"></i> Global Signal Broadcast
             </h3>
             <div className="space-y-6">
                <input value={signal.title} onChange={e => setSignal({...signal, title: e.target.value})} className="w-full bg-[#020617] border border-white/5 rounded-3xl px-8 py-5 text-sm font-bold" placeholder="Signal Header..." />
                <textarea value={signal.message} onChange={e => setSignal({...signal, message: e.target.value})} rows={4} className="w-full bg-[#020617] border border-white/5 rounded-3xl px-8 py-5 text-sm font-medium" placeholder="Signal Payload..." />
                <button onClick={handleSendSignal} className="w-full py-5 bg-amber-600 text-white rounded-3xl font-black uppercase tracking-widest text-[10px] shadow-xl hover:bg-amber-700 transition-all">Transmit Protocol</button>
             </div>
          </div>
        );
      case 'VOUCHERS':
        return (
          <div className="max-w-2xl bg-white/5 p-12 rounded-[4rem] border border-white/5 animate-in slide-in-from-right-10 duration-500">
             <h3 className="text-xl font-black text-white italic uppercase tracking-tighter mb-10 flex items-center gap-4">
                <i className="fa-solid fa-ticket-airline text-purple-500"></i> XP Voucher Engine
             </h3>
             <div className="space-y-6">
                <div className="flex gap-4">
                   <input value={voucher.code} onChange={e => setVoucher({...voucher, code: e.target.value})} className="flex-1 bg-[#020617] border border-white/5 rounded-3xl px-8 py-5 text-sm font-bold uppercase tracking-widest" placeholder="REDEEM-CODE-123" />
                   <button onClick={() => setVoucher({...voucher, code: 'CHIKI-' + Math.random().toString(36).substring(7).toUpperCase()})} className="px-6 bg-slate-800 rounded-2xl text-white text-xs font-black uppercase">Auto</button>
                </div>
                <select value={voucher.reward} onChange={e => setVoucher({...voucher, reward: e.target.value})} className="w-full bg-[#020617] border border-white/5 rounded-3xl px-8 py-5 text-xs font-black uppercase tracking-widest">
                   <option>1000 XP</option>
                   <option>5000 XP</option>
                   <option>VIP STATUS (7D)</option>
                   <option>PLUS ACCESS (24H)</option>
                </select>
                <button onClick={() => { alert('Voucher Created: ' + voucher.code); setVoucher({code: '', reward: '1000 XP'}); }} className="w-full py-5 bg-purple-600 text-white rounded-3xl font-black uppercase tracking-widest text-[10px] shadow-xl hover:bg-purple-700 transition-all">Register Voucher</button>
             </div>
          </div>
        );
      case 'MAINTENANCE':
        return (
          <div className="max-w-lg bg-white/5 p-12 rounded-[4rem] border border-white/5 text-center flex flex-col items-center">
             <i className={`fa-solid fa-power-off text-7xl mb-10 ${maintenance ? 'text-red-500 animate-pulse' : 'text-emerald-500'}`}></i>
             <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">System Continuity Protocol</h3>
             <p className="text-slate-500 text-sm mt-4 mb-10">Freeze global services for emergency infrastructure patches. User nodes will be locked.</p>
             <button onClick={() => { setMaintenance(!maintenance); setAuditLogs([{id: Date.now().toString(), action: maintenance ? 'Services Restored' : 'Initiated Maintenance Mode', time: 'Just now'}, ...auditLogs]); }} className={`w-full py-6 rounded-[2.5rem] font-black uppercase tracking-[0.3em] text-[10px] shadow-2xl transition-all ${maintenance ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}>
                {maintenance ? 'DEACTIVATE FREEZE' : 'ACTIVATE GLOBAL FREEZE'}
             </button>
          </div>
        );
      case 'SYSTEM_HEALTH':
        return (
          <div className="grid grid-cols-2 gap-8 animate-in fade-in duration-700">
             <div className="bg-white/5 p-12 rounded-[4rem] border border-white/5">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-10">Cluster Load Balancing</h3>
                <div className="space-y-8">
                   {[{ l: 'Jakarta Node', v: 42, c: 'bg-blue-500' }, { l: 'Singapore Edge', v: 18, c: 'bg-emerald-500' }, { l: 'US-West Relay', v: 76, c: 'bg-amber-500' }].map((n, i) => (
                      <div key={i} className="space-y-2">
                         <div className="flex justify-between text-[10px] font-black uppercase">
                            <span>{n.l}</span>
                            <span>{n.v}%</span>
                         </div>
                         <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden"><div className={`h-full ${n.c}`} style={{ width: n.v + '%' }}></div></div>
                      </div>
                   ))}
                </div>
             </div>
             <div className="bg-white/5 p-12 rounded-[4rem] border border-white/5 flex flex-col items-center justify-center">
                <div className="text-5xl font-black text-white italic">12ms</div>
                <div className="text-[10px] font-black text-emerald-500 uppercase mt-4 tracking-widest">Packet Latency: Optimal</div>
             </div>
          </div>
        );
      case 'AUDIT_LOGS':
        return (
          <div className="bg-white/5 p-10 rounded-[4rem] border border-white/5 animate-in slide-in-from-bottom-5 duration-500 max-w-4xl">
             <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-10">Administrative Audit Trail</h3>
             <div className="space-y-4">
                {auditLogs.map(log => (
                  <div key={log.id} className="flex items-center justify-between p-6 bg-white/5 rounded-3xl border border-white/5">
                     <span className="text-sm font-bold text-slate-200"><i className="fa-solid fa-receipt text-slate-600 mr-4"></i>{log.action}</span>
                     <span className="text-[10px] font-black text-slate-500 uppercase">{log.time}</span>
                  </div>
                ))}
             </div>
          </div>
        );
      case 'RANK_CONFIG':
        return (
          <div className="max-w-4xl bg-white/5 p-12 rounded-[4rem] border border-white/5">
             <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-10">Rank Threshold Definitions</h3>
             <div className="grid grid-cols-2 gap-8">
                {Object.values(Rank).map((r, i) => (
                  <div key={i} className="bg-white/5 p-6 rounded-3xl border border-white/5 flex items-center justify-between">
                     <RankBadge rank={r} />
                     <input type="number" className="w-24 bg-[#020617] border border-white/5 rounded-xl px-4 py-2 text-xs font-black" placeholder="XP Goal" />
                  </div>
                ))}
             </div>
             <button onClick={() => alert('Rank Config Saved')} className="w-full mt-10 py-5 bg-blue-600 text-white rounded-3xl font-black uppercase tracking-widest text-[10px] shadow-xl">Apply Global Scaling</button>
          </div>
        );
      case 'DATABASE':
        return (
          <div className="grid grid-cols-3 gap-8 max-w-5xl">
             {[
               { l: 'Reset App Metrics', i: 'fa-rotate-left', fn: handleResetDB, c: 'text-amber-500' },
               { l: 'Wipe CDN Cache', i: 'fa-broom-wide', fn: () => alert('Cache Purged'), c: 'text-emerald-500' },
               { l: 'Optimize Indices', i: 'fa-bolt', fn: () => alert('DB Optimized'), c: 'text-blue-500' }
             ].map((tool, i) => (
               <button key={i} onClick={tool.fn} className="bg-white/5 p-12 rounded-[3.5rem] border border-white/5 text-center flex flex-col items-center hover:bg-white/10 transition-all">
                  <i className={`fa-solid ${tool.i} text-4xl mb-6 ${tool.c}`}></i>
                  <p className="text-xs font-black uppercase tracking-widest text-slate-200">{tool.l}</p>
               </button>
             ))}
          </div>
        );
      default:
        return (
          <div className="py-20 text-center flex flex-col items-center bg-white/5 rounded-[4rem] border border-white/5">
             <i className="fa-solid fa-microchip text-6xl text-slate-700 mb-8"></i>
             <h3 className="text-xl font-black text-white italic uppercase">Functional Cluster: {activeTab}</h3>
             <p className="text-slate-500 text-xs mt-2 uppercase tracking-widest">Active node confirmed. Awaiting final dataset binding.</p>
             <button onClick={() => alert(activeTab + ' Module Initialized')} className="mt-10 px-12 py-5 bg-blue-600 text-white rounded-[2rem] text-[10px] font-black uppercase tracking-widest shadow-2xl">Re-init Node</button>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-[#020617] overflow-hidden text-slate-300">
      {/* Sidebar */}
      <aside className="w-72 bg-[#0f172a] border-r border-white/5 flex flex-col">
        <div className="p-8 border-b border-white/5">
          <h1 className="text-xl font-black italic uppercase text-white flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-xs shadow-lg shadow-blue-500/20">
              <i className="fa-solid fa-crown text-white"></i>
            </div>
            CHIKIMOD ADMIN
          </h1>
          <p className="text-[9px] font-black text-slate-500 tracking-[0.4em] mt-3">INFRASTRUCTURE CONTROL</p>
        </div>
        <nav className="flex-1 overflow-y-auto py-6 px-4 custom-scrollbar space-y-1">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all text-[11px] font-black uppercase tracking-widest ${
                activeTab === item.id 
                ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/20' 
                : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
              }`}
            >
              <i className={`fa-solid ${item.icon} w-5 text-base`}></i>
              {item.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* Content Area */}
      <main className="flex-1 overflow-y-auto p-12 custom-scrollbar bg-gradient-to-br from-[#020617] to-[#0f172a]">
        <header className="mb-12 flex justify-between items-end">
          <div>
            <div className="flex items-center gap-3 text-blue-500 text-[10px] font-black uppercase tracking-[0.3em] mb-2">
               <div className="w-2 h-2 rounded-full bg-blue-500 animate-ping"></div>
               Live Cluster Activity
            </div>
            <h2 className="text-5xl font-black text-white italic uppercase tracking-tighter leading-none">
              {navItems.find(n => n.id === activeTab)?.label}
            </h2>
          </div>
          <div className="bg-white/5 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/5 flex items-center gap-4">
             <div className="text-right">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Node Health</p>
                <p className="text-sm font-black text-emerald-500">Secure Cluster</p>
             </div>
             <i className="fa-solid fa-shield-halved text-slate-600 text-2xl"></i>
          </div>
        </header>

        {renderModule()}
      </main>
    </div>
  );
};

export default Admin;
