
import React, { useState } from 'react';
import { User, AppRequest as RequestType } from '../types';
import { MOCK_REQUESTS } from '../constants';

interface AppRequestProps {
  user: User;
}

const AppRequest: React.FC<AppRequestProps> = ({ user }) => {
  const [requests, setRequests] = useState<RequestType[]>(MOCK_REQUESTS);
  const [appName, setAppName] = useState('');

  if (!user.isVIP) {
    return (
      <div className="min-h-screen bg-slate-50 p-6 flex flex-col items-center justify-center text-center pb-24">
        <div className="w-24 h-24 bg-amber-100 rounded-full flex items-center justify-center text-amber-500 text-4xl mb-6 shadow-inner">
          <i className="fa-solid fa-crown"></i>
        </div>
        <h1 className="text-2xl font-black text-slate-900 mb-2 tracking-tight">VIP ACCESS ONLY</h1>
        <p className="text-slate-500 text-sm mb-8 px-6">Special app requests are reserved for our VIP members. Upgrade now to unlock this feature.</p>
        <button className="bg-gradient-to-r from-amber-400 to-amber-600 text-white font-bold py-4 px-10 rounded-2xl shadow-xl shadow-amber-200 active:scale-95 transition-all">
          Upgrade to VIP ($9.99/mo)
        </button>
      </div>
    );
  }

  const handleRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!appName.trim()) return;
    const newReq: RequestType = {
      id: Date.now().toString(),
      appName,
      version: 'Latest',
      status: 'PENDING',
      timestamp: 'Just now'
    };
    setRequests([newReq, ...requests]);
    setAppName('');
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6 pb-24">
      <header className="mb-8">
        <h1 className="text-3xl font-black text-slate-900">VIP Request</h1>
        <p className="text-slate-500 text-sm">Need a specific mod? Tell us below.</p>
      </header>

      <form onSubmit={handleRequest} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 mb-8">
        <div className="space-y-4">
          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 ml-2">Application Name</label>
            <input 
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              placeholder="e.g. Minecraft, Adobe Premiere"
              className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 focus:outline-none focus:ring-2 focus:ring-blue-400 transition-all text-sm"
            />
          </div>
          <button type="submit" className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg active:scale-95 transition-all">
            Submit Request
          </button>
        </div>
      </form>

      <div className="space-y-4">
        <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest px-2">Recent Requests</h2>
        {requests.map(req => (
          <div key={req.id} className="bg-white p-4 rounded-2xl border border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400">
                <i className="fa-solid fa-box"></i>
              </div>
              <div>
                <p className="font-bold text-slate-900">{req.appName}</p>
                <p className="text-[10px] text-slate-400">{req.timestamp} • {req.version}</p>
              </div>
            </div>
            <div className={`px-3 py-1 rounded-full text-[9px] font-bold ${
              req.status === 'DONE' ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600'
            }`}>
              {req.status}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AppRequest;
