
import React, { useState, useRef, useEffect } from 'react';
import { User, ChatMessage, Rank } from '../types';
import RankBadge from './RankBadge';

interface CommunityChatProps {
  currentUser: User;
  onAction: () => void;
}

const CommunityChat: React.FC<CommunityChatProps> = ({ currentUser, onAction }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [messages, isTyping]);

  const handleSendMessage = () => {
    if (!input.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRank: currentUser.rank,
      senderAvatar: currentUser.avatar,
      text: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isMe: true,
      type: 'TEXT'
    };

    setMessages(prev => [...prev, newMessage]);
    setInput('');
    onAction(); // Award XP
  };

  return (
    <div className="flex flex-col h-screen bg-[#f1f3f9] pb-24">
      {/* Header */}
      <header className="bg-white px-6 py-4 flex items-center justify-between shadow-sm border-b border-slate-100 z-10">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-100">
            <i className="fa-solid fa-users-viewfinder text-xl"></i>
          </div>
          <div>
            <h1 className="font-black text-slate-900 tracking-tight flex items-center gap-2">
              GLOBAL LOUNGE
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            </h1>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Live Conversation</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 hover:text-blue-600 transition-all active:scale-90">
            <i className="fa-solid fa-hashtag"></i>
          </button>
        </div>
      </header>

      {/* Chat Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center opacity-30">
            <i className="fa-solid fa-comments text-5xl mb-4 text-slate-300"></i>
            <p className="text-xs font-black uppercase tracking-widest text-slate-400">Belum ada pesan. Mulai ngobrol, bro!</p>
          </div>
        )}
        
        {messages.map((msg, idx) => {
          if (msg.type === 'SYSTEM') {
            return (
              <div key={msg.id} className="flex justify-center">
                <div className="bg-slate-200/50 backdrop-blur-md px-4 py-1.5 rounded-full border border-slate-200 shadow-sm">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-tight italic flex items-center gap-2">
                     <i className="fa-solid fa-bolt text-amber-500"></i>
                     {msg.text}
                   </p>
                </div>
              </div>
            );
          }

          return (
            <div 
              key={msg.id} 
              className={`flex items-end gap-3 ${msg.senderId === currentUser.id ? 'flex-row-reverse' : 'flex-row'} animate-in slide-in-from-bottom-2 duration-300`}
            >
              <div className="flex-shrink-0">
                <img src={msg.senderAvatar} className="w-10 h-10 rounded-2xl shadow-md border-2 border-white object-cover" alt="" />
              </div>
              
              <div className={`max-w-[75%] flex flex-col ${msg.senderId === currentUser.id ? 'items-end' : 'items-start'}`}>
                <div className={`flex items-center gap-2 mb-1 ${msg.senderId === currentUser.id ? 'flex-row-reverse' : 'flex-row'}`}>
                   <span className="text-[10px] font-black text-slate-900">{msg.senderName}</span>
                   <RankBadge rank={msg.senderRank} showText={false} />
                </div>
                
                <div className={`p-4 rounded-[1.8rem] text-sm shadow-sm relative transition-all group ${
                  msg.senderId === currentUser.id 
                  ? 'bg-slate-900 text-white rounded-br-none' 
                  : 'bg-white text-slate-700 rounded-bl-none border border-slate-100'
                }`}>
                  <p className="leading-relaxed font-medium">{msg.text}</p>
                  <div className={`absolute -bottom-5 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300 ${msg.senderId === currentUser.id ? 'right-0' : 'left-0'}`}>
                    <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest">{msg.timestamp}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white border-t border-slate-100">
        <div className="flex gap-3 items-center bg-slate-50 rounded-[2rem] px-6 py-2 border border-slate-200 focus-within:border-blue-400 focus-within:ring-4 focus-within:ring-blue-50 transition-all shadow-inner">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ketik pesan buat komunitas..." 
            className="flex-1 bg-transparent py-4 text-sm focus:outline-none font-medium placeholder:text-slate-300"
          />
          <div className="flex items-center gap-3">
             <button 
               onClick={handleSendMessage}
               disabled={!input.trim()}
               className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
                 input.trim() 
                 ? 'bg-slate-900 text-white shadow-xl shadow-slate-300 scale-100' 
                 : 'bg-slate-200 text-slate-400 scale-90 opacity-50'
               }`}
             >
               <i className="fa-solid fa-paper-plane text-sm"></i>
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommunityChat;
