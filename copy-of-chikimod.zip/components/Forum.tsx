
import React, { useState, useRef } from 'react';
import { MOCK_POSTS } from '../constants';
import { Rank, Comment, ForumPost } from '../types';
import RankBadge from './RankBadge';

interface ForumProps {
  onAction: () => void;
  onNotifyBellClick: () => void;
  unreadCount: number;
  onReport: (id: string, type: 'POST', name: string) => void;
  onSimulateNotification: (title: string, message: string, type: 'COMMENT') => void;
}

const ForumVideoPlayer: React.FC<{ url: string }> = ({ url }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="relative rounded-[2.5rem] overflow-hidden bg-black group aspect-[9/16] max-h-[500px] w-full mx-auto shadow-2xl border border-gray-100/10">
      <video
        ref={videoRef}
        src={url}
        className="w-full h-full object-cover"
        loop
        playsInline
        onClick={togglePlay}
      />
      {!isPlaying && (
        <div 
          onClick={togglePlay}
          className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[2px] cursor-pointer group-hover:bg-black/10 transition-all"
        >
          <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/30 text-white text-2xl animate-pulse">
            <i className="fa-solid fa-play ml-1"></i>
          </div>
        </div>
      )}
      <div className="absolute bottom-6 right-6 flex flex-col gap-4 text-white">
        <button className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
          <i className="fa-solid fa-music text-xs animate-spin-slow"></i>
        </button>
      </div>
    </div>
  );
};

const PostContent: React.FC<{ content: string }> = ({ content }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const maxLength = 140;
  const isLong = content.length > maxLength;

  return (
    <div className="mb-4">
      <p className={`text-slate-700 text-[13px] leading-relaxed px-1 transition-all duration-500 ${!isExpanded && isLong ? 'line-clamp-3' : ''}`}>
        {content}
      </p>
      {isLong && (
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-blue-600 text-[10px] font-black uppercase mt-2 px-1 hover:underline tracking-widest"
        >
          {isExpanded ? 'Collapse' : 'Read Full Thread'}
        </button>
      )}
    </div>
  );
};

const Forum: React.FC<ForumProps> = ({ onAction, onNotifyBellClick, unreadCount, onReport, onSimulateNotification }) => {
  const [posts, setPosts] = useState<ForumPost[]>(MOCK_POSTS.map(p => ({ ...p, commentList: p.commentList || [] })));
  const [newPostContent, setNewPostContent] = useState('');
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);
  const [expandedComments, setExpandedComments] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState<string>('');
  const videoInputRef = useRef<HTMLInputElement>(null);

  const handlePost = () => {
    if (!newPostContent.trim() && !selectedVideo) return;
    const post: ForumPost = {
      id: Date.now().toString(),
      userId: (window as any).currentUser?.id || 'guest',
      userName: (window as any).currentUser?.name || 'Guest',
      userRank: (window as any).currentUser?.rank || Rank.BRONZE,
      content: newPostContent,
      timestamp: 'Just now',
      likes: 0,
      comments: 0,
      video: selectedVideo || undefined,
      commentList: []
    };
    setPosts([post, ...posts]);
    setNewPostContent('');
    setSelectedVideo(null);
    onAction();
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const url = URL.createObjectURL(e.target.files[0]);
      setSelectedVideo(url);
    }
  };

  const handleLike = (postId: string) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return { ...p, likes: p.likes + 1 };
      }
      return p;
    }));
    onAction();
  };

  const handleAddComment = (postId: string) => {
    if (!commentInput.trim()) return;

    const newComment: Comment = {
      id: `c-${Date.now()}`,
      userId: (window as any).currentUser?.id || 'guest',
      userName: (window as any).currentUser?.name || 'Guest',
      userRank: (window as any).currentUser?.rank || Rank.BRONZE,
      avatar: (window as any).currentUser?.avatar || 'https://picsum.photos/seed/guest/40',
      text: commentInput,
      timestamp: 'Just now'
    };

    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          comments: p.comments + 1,
          commentList: [...(p.commentList || []), newComment]
        };
      }
      return p;
    }));

    setCommentInput('');
    onAction();
  };

  const toggleComments = (postId: string) => {
    setExpandedComments(expandedComments === postId ? null : postId);
  };

  return (
    <div className="bg-[#fcfcfc] min-h-screen pb-24">
      <div className="sticky top-0 bg-white/90 backdrop-blur-xl z-30 px-6 py-4 border-b border-gray-100 flex items-center justify-between">
        <h1 className="text-2xl font-black text-slate-900 italic tracking-tighter uppercase">Community</h1>
        <div className="flex gap-4 items-center">
          <button onClick={onNotifyBellClick} className="relative active:scale-95 transition-transform p-1">
            <i className="fa-solid fa-bell text-slate-400 text-xl"></i>
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-white">
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Create Post */}
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-gray-100 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="flex gap-4 mb-4">
            <img src={(window as any).currentUser?.avatar || "https://picsum.photos/seed/me/40"} className="w-12 h-12 rounded-[1.2rem] border-2 border-gray-50 shadow-sm flex-shrink-0" alt="Me" />
            <textarea 
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              placeholder="Apa yang lo pikirin hari ini? Bagi mod atau video reels keren lo di sini..." 
              className="flex-1 bg-gray-50 rounded-2xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 min-h-[110px] transition-all resize-none"
            />
          </div>

          {selectedVideo && (
            <div className="relative mb-4 rounded-2xl overflow-hidden aspect-video bg-black border border-gray-100">
              <video src={selectedVideo} className="w-full h-full object-cover" />
              <button 
                onClick={() => setSelectedVideo(null)}
                className="absolute top-2 right-2 w-8 h-8 bg-black/50 text-white rounded-full flex items-center justify-center backdrop-blur-md"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
          )}

          <div className="flex justify-between items-center px-2">
            <div className="flex gap-3">
              <input 
                type="file" 
                ref={videoInputRef} 
                className="hidden" 
                accept="video/*" 
                onChange={handleVideoUpload}
              />
              <button 
                onClick={() => videoInputRef.current?.click()}
                className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${selectedVideo ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-600 hover:bg-blue-100'}`}
                title="Upload Short Video"
              >
                <i className="fa-solid fa-video"></i>
              </button>
              <button className="w-10 h-10 rounded-xl bg-gray-50 text-gray-400 flex items-center justify-center hover:bg-gray-100">
                <i className="fa-solid fa-image"></i>
              </button>
            </div>
            <button 
              onClick={handlePost}
              className="bg-slate-900 text-white px-8 py-2.5 rounded-2xl text-[11px] font-black uppercase shadow-xl hover:bg-slate-800 transition-all active:scale-95 tracking-widest"
            >
              Post Now
            </button>
          </div>
        </div>

        {/* Post List */}
        <div className="space-y-8">
          {posts.map(post => (
            <div key={post.id} className="bg-white rounded-[2.8rem] shadow-sm border border-gray-50 overflow-hidden hover:shadow-xl transition-all duration-700 animate-in fade-in slide-in-from-bottom-8 duration-700">
              <div className="p-6">
                <div className="flex items-center gap-4 mb-5">
                  <img src={`https://picsum.photos/seed/${post.userName}/40`} className="w-12 h-12 rounded-[1.3rem] border border-gray-100 shadow-sm" alt="" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-black text-slate-900 text-sm">{post.userName}</span>
                      <RankBadge rank={post.userRank} />
                    </div>
                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{post.timestamp}</span>
                  </div>
                </div>
                
                <PostContent content={post.content} />
                
                {post.video && (
                  <div className="mb-6">
                    <ForumVideoPlayer url={post.video} />
                  </div>
                )}

                {post.image && !post.video && (
                  <div className="rounded-[2rem] overflow-hidden mb-6 border border-gray-50 shadow-md group">
                    <img src={post.image} className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-[2s]" alt="" />
                  </div>
                )}

                <div className="flex items-center justify-between pt-5 border-t border-gray-50">
                  <div className="flex gap-8">
                    <button 
                      onClick={() => handleLike(post.id)}
                      className="flex items-center gap-2 text-slate-300 text-xs hover:text-red-500 transition-all group"
                    >
                      <i className={`fa-solid fa-heart text-lg group-hover:scale-125 transition-transform ${post.likes > 0 ? 'text-red-500' : ''}`}></i>
                      <span className="font-black tabular-nums">{post.likes}</span>
                    </button>
                    <button 
                      onClick={() => toggleComments(post.id)}
                      className="flex items-center gap-2 text-slate-300 text-xs hover:text-blue-600 transition-all group"
                    >
                      <i className="fa-solid fa-comment-dots text-lg group-hover:scale-125 transition-transform"></i>
                      <span className="font-black tabular-nums">{post.comments}</span>
                    </button>
                  </div>
                </div>

                {/* Comments Section */}
                {expandedComments === post.id && (
                  <div className="mt-6 pt-6 border-t border-gray-50 space-y-5 animate-in slide-in-from-top-4 duration-500">
                    <div className="space-y-4 max-h-[300px] overflow-y-auto custom-scrollbar pr-2">
                      {post.commentList?.map(comment => (
                        <div key={comment.id} className="flex gap-4 items-start animate-in fade-in zoom-in duration-300">
                          <img src={comment.avatar || `https://picsum.photos/seed/${comment.userName}/40`} className="w-9 h-9 rounded-xl border border-gray-50 shadow-sm" alt="" />
                          <div className="flex-1 bg-gray-50/50 rounded-2xl p-4 border border-gray-50">
                            <div className="flex items-center justify-between mb-1.5">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-black text-slate-900">{comment.userName}</span>
                                <RankBadge rank={comment.userRank} showText={false} />
                              </div>
                              <span className="text-[9px] text-gray-400 font-bold">{comment.timestamp}</span>
                            </div>
                            <p className="text-xs text-slate-600 leading-relaxed font-medium">{comment.text}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex gap-4 items-center pt-2">
                      <img src={(window as any).currentUser?.avatar || "https://picsum.photos/seed/me/40"} className="w-10 h-10 rounded-xl border border-gray-50 shadow-sm" alt="" />
                      <div className="flex-1 bg-white border border-gray-200 rounded-2xl px-5 py-3 flex items-center shadow-inner focus-within:ring-2 focus-within:ring-blue-100 transition-all">
                        <input 
                          type="text" 
                          value={commentInput}
                          onChange={(e) => setCommentInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleAddComment(post.id)}
                          placeholder="Ketik balasan lo..."
                          className="bg-transparent flex-1 text-xs focus:outline-none font-medium"
                        />
                        <button 
                          onClick={() => handleAddComment(post.id)}
                          className="text-blue-600 hover:text-blue-800 transition-colors ml-3 active:scale-90"
                        >
                          <i className="fa-solid fa-paper-plane text-base"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Forum;
