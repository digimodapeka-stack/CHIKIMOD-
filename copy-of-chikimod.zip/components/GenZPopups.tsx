
import React, { useState } from 'react';

interface GenZPopupsProps {
  onComplete: () => void;
}

const GenZPopups: React.FC<GenZPopupsProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);

  const handleNext = () => {
    if (step === 1) {
      setStep(2);
    } else {
      onComplete();
    }
  };

  return (
    <div className="fixed inset-0 z-[9998] bg-black/60 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
      {step === 1 ? (
        /* Card 1: Kata-kata Gen Z */
        <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[3rem] p-10 shadow-2xl border-t-[10px] border-blue-600 animate-in zoom-in slide-in-from-bottom-10 duration-500 text-center">
          <div className="w-20 h-20 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center text-blue-600 text-3xl mx-auto mb-8">
            <i className="fa-solid fa-quote-left"></i>
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white italic uppercase tracking-tighter mb-4">Vibe Check! ✨</h2>
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400 leading-relaxed italic mb-10 px-2">
            "Hidup itu kayak modding, bro. Kalo ada error ya tinggal di-debug, bukan malah di-ghosting. Stay chill, keep modding, dan jangan lupa bahagia hari ini!"
          </p>
          <button 
            onClick={handleNext}
            className="w-full py-5 bg-slate-900 dark:bg-blue-600 text-white rounded-2xl font-black uppercase text-[11px] tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-xl"
          >
            Lanjut Ngab!
          </button>
        </div>
      ) : (
        /* Card 2: Promo VIP Bahasa Gaul */
        <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[3rem] p-10 shadow-2xl border-t-[10px] border-amber-500 animate-in zoom-in duration-500 text-center">
          <div className="w-20 h-20 bg-amber-50 dark:bg-amber-900/20 rounded-full flex items-center justify-center text-amber-500 text-4xl mx-auto mb-8 animate-bounce">
            <i className="fa-solid fa-crown"></i>
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white italic uppercase tracking-tighter mb-4">Makin Pro, Makin Kece 🔥</h2>
          <p className="text-sm font-black text-amber-600 uppercase tracking-widest mb-4">CHIKIMOD VIP ACCESS</p>
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400 leading-relaxed mb-10 px-2">
            Gak pake iklan, akses makin sat-set-sat-set, mod fitur lebih gila. Jangan cuma jadi penonton doang, join VIP sekarang biar aura lo makin bintang lima! 🌟
          </p>
          <div className="space-y-3">
            <button 
              onClick={handleNext}
              className="w-full py-5 bg-amber-500 text-white rounded-2xl font-black uppercase text-[11px] tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-xl"
            >
              Gassken VIP!
            </button>
            <button 
              onClick={handleNext}
              className="w-full py-4 text-[10px] font-black uppercase text-slate-400 hover:text-slate-600 transition-colors"
            >
              Nanti Aja Deh
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default GenZPopups;
