
import React from 'react';
import { User, Rank } from '../types';
import RankBadge from './RankBadge';
import { RANK_CONFIG } from '../constants';

interface LeaderboardProps {
  users: User[];
  isDarkMode: boolean;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ users, isDarkMode }) => {
  const sortedUsers = [...users].sort((a, b) => b.points - a.points);
  
  const textColor = isDarkMode ? 'text-white' : 'text-slate-900';
  const cardBg = isDarkMode ? 'bg-slate-900' : 'bg-white';
  const borderColor = isDarkMode ? 'border-slate-800' : 'border-slate-100';
  const subTextColor = isDarkMode ? 'text-slate-400' : 'text-slate-500';

  // Group users by rank for a "tiered" view if needed, but standard list is cleaner for mobile
  // We'll add tier separators in the list
  const getRankColor = (rank: Rank) => RANK_CONFIG[rank].color;

  return (
    <div className={`min-h-screen pb-32 transition-colors duration-500 ${isDarkMode ? 'bg-slate-950' : 'bg-[#f8faff]'}`}>
      {/* Cinematic Header & Podium */}
      <div className="bg-black text-white pt-16 pb-28 rounded-b-[4rem] sm:rounded-b-[6rem] shadow-2xl relative overflow-hidden border-b-8 border-blue-600">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
           <i className="fa-solid fa-ranking-star text-[30rem] absolute -bottom-40 -right-40 rotate-12"></i>
        </div>
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-blue-900/20 to-transparent"></div>
        
        <div className="relative z-10 text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-black italic tracking-tighter uppercase px-6">
            CHIKIMOD <span className="text-blue-500">LEGENDS</span>
          </h1>
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.5em] mt-2">Elite Node Ranking Protocol</p>
        </div>
        
        {/* Top 3 Podium - Precise Grid Alignment */}
        <div className="flex justify-center items-end gap-2 sm:gap-4 px-4 relative z-10 max-w-2xl mx-auto h-72">
          
          {/* 2nd Place */}
          {sortedUsers[1] && (
            <div className="flex flex-col items-center flex-1 h-full justify-end animate-in slide-in-from-bottom-10 duration-700">
              <div className="relative group mb-4">
                <div className="absolute -inset-1 bg-gray-400 rounded-[2rem] blur-sm opacity-30 group-hover:opacity-60 transition"></div>
                <img src={sortedUsers[1].avatar} className="w-16 h-16 sm:w-24 sm:h-24 rounded-[2rem] border-4 border-gray-400 p-0.5 relative z-10 shadow-xl object-cover" alt="" />
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-gray-400 text-black w-8 h-8 rounded-xl flex items-center justify-center text-sm font-black border-2 border-black z-20 shadow-lg">2</div>
              </div>
              <p className="text-[10px] font-black truncate w-full text-center uppercase tracking-tighter text-gray-400 px-2">{sortedUsers[1].name}</p>
              <div className="h-20 w-full bg-gradient-to-t from-gray-400/20 to-transparent mt-4 rounded-t-3xl border-x border-t border-white/5"></div>
            </div>
          )}
          
          {/* 1st Place - The King */}
          {sortedUsers[0] && (
            <div className="flex flex-col items-center flex-1 h-full justify-end animate-in slide-in-from-bottom-12 duration-1000">
              <div className="relative group mb-6">
                <div className="absolute -top-12 left-1/2 -translate-x-1/2 text-amber-400 text-4xl animate-bounce drop-shadow-[0_0_15px_rgba(251,191,36,0.5)]">
                  <i className="fa-solid fa-crown"></i>
                </div>
                <div className="absolute -inset-2 bg-amber-400 rounded-[3rem] blur-md opacity-20 group-hover:opacity-40 transition"></div>
                <img src={sortedUsers[0].avatar} className="w-24 h-24 sm:w-32 sm:h-32 rounded-[3rem] border-4 border-amber-400 p-1 relative z-10 shadow-2xl object-cover" alt="" />
                <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-amber-400 text-black w-10 h-10 rounded-2xl flex items-center justify-center text-xl font-black border-4 border-black z-20 shadow-2xl">1</div>
              </div>
              <p className="text-sm font-black uppercase tracking-tight text-white mb-1 px-2 text-center">{sortedUsers[0].name}</p>
              <p className="text-xs font-black text-amber-400 drop-shadow-md tracking-[0.2em]">{sortedUsers[0].points.toLocaleString()} XP</p>
              <div className="h-36 w-full bg-gradient-to-t from-amber-400/20 to-transparent mt-4 rounded-t-3xl border-x border-t border-amber-400/20"></div>
            </div>
          )}

          {/* 3rd Place */}
          {sortedUsers[2] && (
            <div className="flex flex-col items-center flex-1 h-full justify-end animate-in slide-in-from-bottom-10 duration-700 delay-100">
              <div className="relative group mb-4">
                <div className="absolute -inset-1 bg-orange-600 rounded-[2rem] blur-sm opacity-30 group-hover:opacity-60 transition"></div>
                <img src={sortedUsers[2].avatar} className="w-16 h-16 sm:w-24 sm:h-24 rounded-[2rem] border-4 border-orange-600/50 p-0.5 relative z-10 shadow-xl object-cover" alt="" />
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-orange-600 text-black w-8 h-8 rounded-xl flex items-center justify-center text-sm font-black border-2 border-black z-20 shadow-lg">3</div>
              </div>
              <p className="text-[10px] font-black truncate w-full text-center uppercase tracking-tighter text-gray-400 px-2">{sortedUsers[2].name}</p>
              <div className="h-14 w-full bg-gradient-to-t from-orange-600/20 to-transparent mt-4 rounded-t-3xl border-x border-t border-white/5"></div>
            </div>
          )}
        </div>
      </div>

      {/* Tiers Navigation / Info */}
      <div className="px-6 -mt-12 relative z-20 flex gap-2 overflow-x-auto no-scrollbar pb-6 scroll-smooth max-w-4xl mx-auto">
         {Object.values(Rank).reverse().map(rank => (
            <div key={rank} className={`flex-shrink-0 px-4 py-2 rounded-2xl border bg-white dark:bg-slate-900 shadow-xl flex items-center gap-2 border-slate-100 dark:border-white/5`}>
               <i className={`${RANK_CONFIG[rank].icon}`} style={{ color: RANK_CONFIG[rank].color }}></i>
               <span className={`text-[9px] font-black uppercase tracking-widest ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{rank}</span>
            </div>
         ))}
      </div>

      {/* Main Ranked List */}
      <div className="px-4 space-y-3 max-w-3xl mx-auto">
        {sortedUsers.map((user, index) => {
          const isTop3 = index < 3;
          return (
            <div 
              key={user.id} 
              className={`flex items-center gap-4 p-4 rounded-[2.5rem] border transition-all duration-500 group ${cardBg} ${borderColor} ${isTop3 ? 'shadow-lg border-blue-500/20' : 'shadow-sm hover:shadow-xl hover:translate-x-1'}`}
            >
              {/* Rank Pos */}
              <div className="w-12 flex-shrink-0 flex items-center justify-center">
                 <span className={`text-2xl font-black italic tabular-nums ${isTop3 ? 'text-blue-600' : 'text-slate-300'}`}>
                   {index + 1}
                 </span>
              </div>
              
              {/* Avatar */}
              <div className="relative flex-shrink-0">
                <div className={`absolute -inset-1 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`} style={{ backgroundColor: getRankColor(user.rank) + '20' }}></div>
                <img src={user.avatar} className="w-14 h-14 rounded-[1.5rem] shadow-md object-cover border-2 border-white dark:border-slate-800 relative z-10" alt="" />
                <div className={`absolute -top-1 -right-1 w-4 h-4 rounded-full border-2 border-white dark:border-slate-900 z-20 ${user.status === 'online' ? 'bg-green-500' : 'bg-slate-400'}`}></div>
              </div>

              {/* User Identity */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <p className={`font-black text-base truncate italic uppercase tracking-tight ${textColor}`}>{user.nickname || user.name}</p>
                  {user.isVIP && <i className="fa-solid fa-circle-check text-blue-500 text-[10px]"></i>}
                  {user.isPLUS && <i className="fa-solid fa-sparkles text-purple-500 text-[10px]"></i>}
                </div>
                <div className="flex">
                   <RankBadge rank={user.rank} />
                </div>
              </div>

              {/* Stats Aligned Right */}
              <div className="text-right flex-shrink-0 pl-4 border-l border-slate-100 dark:border-white/5">
                <p className="font-black text-blue-600 text-lg sm:text-xl tabular-nums leading-none mb-1">
                  {user.points.toLocaleString()}
                </p>
                <p className="text-[8px] text-slate-400 uppercase font-black tracking-widest">Node XP</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Info */}
      <div className="mt-12 text-center pb-20 px-10">
         <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mb-4">Engagement Distribution</p>
         <div className="flex justify-center gap-6 opacity-30">
            <i className="fa-solid fa-microchip text-2xl"></i>
            <i className="fa-solid fa-bolt-lightning text-2xl"></i>
            <i className="fa-solid fa-shield-halved text-2xl"></i>
         </div>
      </div>
    </div>
  );
};

export default Leaderboard;
