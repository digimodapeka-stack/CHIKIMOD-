
import React, { useState } from 'react';
import { AppNotification } from '../types';

interface NotificationCenterProps {
  notifications: AppNotification[];
  onClose: () => void;
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({ 
  notifications, 
  onClose, 
  onMarkRead, 
  onClearAll 
}) => {
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'UNREAD'>('ALL');

  const getTypeStyles = (type: AppNotification['type']) => {
    switch (type) {
      case 'COMMENT': return { icon: 'fa-comment', color: 'text-blue-500', bg: 'bg-blue-50', label: 'Komentar' };
      case 'UPDATE': return { icon: 'fa-download', color: 'text-green-500', bg: 'bg-green-50', label: 'Update' };
      case 'MESSAGE': return { icon: 'fa-envelope', color: 'text-purple-500', bg: 'bg-purple-50', label: 'Pesan' };
      case 'VIP': return { icon: 'fa-crown', color: 'text-amber-500', bg: 'bg-amber-50', label: 'VIP Alert' };
      case 'SYSTEM': return { icon: 'fa-bolt', color: 'text-slate-500', bg: 'bg-slate-50', label: 'Sistem' };
      case 'STREAK': return { icon: 'fa-fire', color: 'text-orange-500', bg: 'bg-orange-50', label: 'Streak' };
      default: return { icon: 'fa-bell', color: 'text-gray-500', bg: 'bg-gray-50', label: 'Notifikasi' };
    }
  };

  const filteredNotifications = activeFilter === 'ALL' 
    ? notifications 
    : notifications.filter(n => !n.read);

  return (
    <div className="absolute top-14 right-4 w-85 max-h-[500px] bg-white rounded-[2rem] shadow-2xl border border-slate-100 z-[100] flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
      <div className="p-6 border-b border-slate-50 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h3 className="font-black text-slate-900 uppercase italic tracking-tighter">Cluster Alerts</h3>
          <div className="flex gap-4">
            <button onClick={onClearAll} className="text-[10px] font-black text-red-500 uppercase tracking-widest hover:underline">Clear Hub</button>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-900 transition-colors">
              <i className="fa-solid fa-xmark text-lg"></i>
            </button>
          </div>
        </div>
        
        <div className="flex gap-2 bg-slate-50 p-1 rounded-xl">
          <button 
            onClick={() => setActiveFilter('ALL')}
            className={`flex-1 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${activeFilter === 'ALL' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
          >
            All Active
          </button>
          <button 
            onClick={() => setActiveFilter('UNREAD')}
            className={`flex-1 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${activeFilter === 'UNREAD' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
          >
            New Unread
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2 bg-slate-50/30">
        {filteredNotifications.length === 0 ? (
          <div className="py-20 text-center flex flex-col items-center">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center text-slate-300 mb-4">
              <i className="fa-solid fa-bell-slash text-2xl"></i>
            </div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">No active signals found</p>
          </div>
        ) : (
          filteredNotifications.map(notif => {
            const styles = getTypeStyles(notif.type);
            return (
              <div 
                key={notif.id} 
                onClick={() => onMarkRead(notif.id)}
                className={`p-4 rounded-2xl cursor-pointer transition-all border flex gap-4 ${notif.read ? 'opacity-50 bg-white border-transparent' : 'bg-white border-blue-100 shadow-sm hover:translate-x-1'}`}
              >
                <div className={`w-12 h-12 rounded-xl flex-shrink-0 flex items-center justify-center shadow-inner ${styles.bg} ${styles.color}`}>
                  <i className={`fa-solid ${styles.icon} text-lg`}></i>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center mb-1">
                    <span className={`text-[8px] font-black uppercase tracking-widest ${styles.color}`}>{styles.label}</span>
                    <span className="text-[8px] font-bold text-slate-300">{notif.timestamp}</span>
                  </div>
                  <p className="text-xs font-black text-slate-900 mb-0.5 truncate">{notif.title}</p>
                  <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed font-medium">{notif.message}</p>
                </div>
                {!notif.read && <div className="w-2.5 h-2.5 rounded-full bg-blue-600 mt-1 shadow-sm shadow-blue-300"></div>}
              </div>
            );
          })
        )}
      </div>
      
      <div className="p-4 bg-white border-t border-slate-50 text-center">
        <button className="text-[9px] font-black text-slate-400 hover:text-blue-600 uppercase tracking-[0.2em] transition-colors">
          Initialize System Audit Log
        </button>
      </div>
    </div>
  );
};

export default NotificationCenter;
