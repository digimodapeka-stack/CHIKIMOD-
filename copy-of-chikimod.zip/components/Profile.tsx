
import React, { useState, useEffect } from 'react';
import { User, Rank, PrivacySettings, NotificationPreferences, SocialLinks } from '../types';
import RankBadge from './RankBadge';
import { RANK_CONFIG } from '../constants';

interface ProfileProps {
  isLoggedIn: boolean;
  onLogin: (email: string) => void;
  onLogout: () => void;
  user: User | null;
  onAdminToggle: () => void;
  onUpdatePrivacy: (settings: PrivacySettings) => void;
  onUpdateProfile: (data: Partial<User>) => void;
  isDarkMode: boolean;
  onAddPoints: (points: number) => void;
  onAddNotification: (title: string, msg: string, type: any) => void;
}

type EditTab = 'IDENTITY' | 'VISUALS' | 'SOCIALS' | 'PROTOCOLS' | 'SECURITY';

const Profile: React.FC<ProfileProps> = ({ 
  isLoggedIn, 
  onLogin, 
  onLogout,
  user, 
  onAdminToggle, 
  onUpdatePrivacy, 
  onUpdateProfile, 
  isDarkMode, 
  onAddPoints, 
  onAddNotification 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [activeEditTab, setActiveEditTab] = useState<EditTab>('IDENTITY');
  
  // Login form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // Comprehensive Edit states
  const [editData, setEditData] = useState<Partial<User>>({});

  useEffect(() => {
    if (user) {
      setEditData({ ...user });
    }
  }, [user, isEditing]);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Masukkan identitas akses lo!');
      return;
    }
    onLogin(email);
  };

  const handleSaveProfile = () => {
    onUpdateProfile(editData);
    setIsEditing(false);
    onAddNotification('Configuration Synced 🌀', 'Profil lo udah berhasil diperbarui di seluruh node.', 'SYSTEM');
  };

  const updateNestedPref = (key: keyof NotificationPreferences, val: boolean) => {
    const newPrefs = { ...editData.notificationPreferences, [key]: val } as NotificationPreferences;
    setEditData({ ...editData, notificationPreferences: newPrefs });
  };

  const updatePrivacy = (key: keyof PrivacySettings, val: boolean) => {
    const newPriv = { ...editData.privacy, [key]: val } as PrivacySettings;
    setEditData({ ...editData, privacy: newPriv });
  };

  const updateSocial = (key: keyof SocialLinks, val: string) => {
    const newSocials = { ...editData.socials, [key]: val } as SocialLinks;
    setEditData({ ...editData, socials: newSocials });
  };

  const getRankProgress = () => {
    if (!user) return 0;
    const thresholds: Record<Rank, number> = {
      [Rank.BRONZE]: 500,
      [Rank.SILVER]: 1500,
      [Rank.GOLD]: 3000,
      [Rank.PLATINUM]: 5000,
      [Rank.DIAMOND]: 8000,
      [Rank.MASTER]: 10000,
      [Rank.GRANDMASTER]: 10000,
    };
    const currentThreshold = thresholds[user.rank];
    const prevThreshold = Object.values(thresholds)[Object.keys(thresholds).indexOf(user.rank) - 1] || 0;
    if (user.rank === Rank.GRANDMASTER) return 100;
    const progress = ((user.points - prevThreshold) / (currentThreshold - prevThreshold)) * 100;
    return Math.min(Math.max(progress, 0), 100);
  };

  const nextRank = () => {
    if (!user) return Rank.BRONZE;
    const ranks = Object.values(Rank);
    const currentIndex = ranks.indexOf(user.rank);
    return ranks[currentIndex + 1] || user.rank;
  };

  const bgColor = isDarkMode ? 'bg-[#020617]' : 'bg-[#f8faff]';
  const cardBg = isDarkMode ? 'bg-slate-900' : 'bg-white';
  const borderColor = isDarkMode ? 'border-slate-800' : 'border-slate-100';
  const textColor = isDarkMode ? 'text-white' : 'text-slate-900';
  const subTextColor = isDarkMode ? 'text-slate-400' : 'text-slate-500';

  if (!isLoggedIn) {
    return (
      <div className={`min-h-screen flex items-center justify-center p-8 transition-colors duration-500 ${bgColor}`}>
        <div className={`w-full max-w-md p-12 rounded-[4.5rem] shadow-2xl border-b-[12px] border-blue-600 animate-in zoom-in duration-700 ${cardBg} border ${borderColor}`}>
           <div className="flex flex-col items-center mb-12 text-center">
              <div className="w-24 h-24 bg-black rounded-[2.5rem] flex items-center justify-center text-white text-5xl mb-6 shadow-2xl shadow-blue-500/30">
                <i className="fa-solid fa-bolt"></i>
              </div>
              <h1 className="text-4xl font-black text-black dark:text-white italic uppercase tracking-tighter">CHIKIMOD ACCESS</h1>
              <p className="text-slate-400 text-[10px] uppercase font-black tracking-[0.5em] mt-3">Identity Encryption Protocol</p>
           </div>
           
           <form onSubmit={handleLoginSubmit} className="space-y-6">
              {error && <div className="bg-red-600 text-white p-4 rounded-3xl text-[10px] font-black uppercase text-center animate-bounce">{error}</div>}
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Authorized Email</label>
                <input 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  placeholder="name@chikimod.com" 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-3xl px-8 py-5 focus:outline-none focus:border-black text-sm font-black text-black transition-all dark:bg-black/20 dark:border-white/5 dark:text-white" 
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Access Secret</label>
                <input 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  placeholder="••••••••" 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-3xl px-8 py-5 focus:outline-none focus:border-black text-sm font-black text-black transition-all dark:bg-black/20 dark:border-white/5 dark:text-white" 
                />
              </div>
              <button type="submit" className="w-full bg-black text-white font-black py-7 rounded-[3rem] shadow-2xl hover:bg-slate-900 transition-all uppercase tracking-[0.5em] text-[12px] mt-4 active:scale-95">
                Initialize Connect
              </button>
           </form>
           <p className="mt-10 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest">
             No active node? <span className="text-blue-600 hover:underline cursor-pointer">Register Cluster</span>
           </p>
        </div>
      </div>
    );
  }

  const rankConfig = user ? RANK_CONFIG[user.rank] : RANK_CONFIG[Rank.BRONZE];

  return (
    <div className={`min-h-screen pb-32 transition-colors duration-500 ${bgColor}`}>
      {/* Immersive Profile Header */}
      <div className="relative h-80 overflow-hidden group">
        <img 
          src={user?.banner || 'https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&q=80&w=1000'} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" 
          alt="Profile Banner" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent"></div>
        
        <div className="absolute top-10 left-10 flex gap-4">
          {user?.isAdmin && (
            <button onClick={onAdminToggle} className="w-14 h-14 bg-white/10 backdrop-blur-2xl rounded-2xl flex items-center justify-center border border-white/20 text-white shadow-2xl hover:bg-white hover:text-black transition-all">
              <i className="fa-solid fa-gear-complex text-xl"></i>
            </button>
          )}
          <button onClick={onLogout} className="w-14 h-14 bg-red-600/20 backdrop-blur-2xl rounded-2xl flex items-center justify-center border border-red-500/20 text-white shadow-2xl hover:bg-red-600 transition-all" title="Logout">
            <i className="fa-solid fa-right-from-bracket text-xl"></i>
          </button>
        </div>

        <div className="absolute bottom-10 left-10 right-10 flex justify-between items-end">
           <div className="flex flex-col gap-2">
              <div className="flex items-center gap-4">
                 <h2 className="text-white text-3xl font-black italic uppercase tracking-tighter">{user?.nickname || user?.name}</h2>
                 <RankBadge rank={user?.rank || Rank.BRONZE} />
              </div>
              <p className="text-white/70 text-[11px] font-black uppercase tracking-[0.4em] flex items-center gap-3">
                <i className="fa-solid fa-location-crosshairs text-blue-500"></i> {user?.location || 'Unidentified Sector'}
              </p>
           </div>
           <button onClick={() => setIsEditing(true)} className="px-8 py-3 bg-white text-black font-black uppercase text-[11px] rounded-[2rem] shadow-2xl hover:bg-blue-600 hover:text-white active:scale-95 transition-all tracking-widest">
             Configure Node
           </button>
        </div>
      </div>

      <div className="px-10 -mt-24 relative z-10">
        <div className="flex flex-col items-center mb-12">
           <div className="relative group">
              <div className="absolute -inset-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-[3.5rem] blur opacity-40 group-hover:opacity-80 transition duration-1000"></div>
              <img src={user?.avatar} className="w-48 h-48 rounded-[3rem] border-8 border-white dark:border-slate-900 shadow-2xl object-cover relative z-10" alt="" />
              <div className={`absolute bottom-4 right-4 w-10 h-10 rounded-full border-6 border-white dark:border-slate-900 z-20 ${user?.status === 'online' ? 'bg-emerald-500' : 'bg-slate-500'}`}></div>
           </div>
           
           {/* Custom Status Bubble */}
           <div className="mt-8 text-center max-w-sm">
              <div className="bg-blue-600/10 dark:bg-blue-600/20 px-8 py-3 rounded-[2rem] border-2 border-blue-500/20 inline-block shadow-lg">
                <p className="text-blue-600 dark:text-blue-400 text-sm font-black italic tracking-tight leading-relaxed">
                   "{user?.customStatus || 'Initializing profile metadata...'}"
                </p>
              </div>
           </div>

           <h2 className={`mt-6 text-4xl font-black italic tracking-tighter uppercase ${textColor}`}>{user?.name} <span className="text-slate-400 dark:text-slate-600 not-italic font-bold">#{user?.tag}</span></h2>
        </div>

        {/* Engagement Progression */}
        <div className={`rounded-[3.5rem] p-10 border shadow-2xl transition-all duration-500 mb-10 ${cardBg} ${borderColor}`}>
           <div className="flex justify-between items-center mb-6">
              <div className="flex flex-col">
                 <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Node Level Progress</p>
                 <p className={`text-xl font-black italic ${textColor}`}>{user?.rank}</p>
              </div>
              <div className="text-right">
                 <p className="text-[11px] font-black text-blue-500 uppercase tracking-widest">Upgrading to</p>
                 <p className={`text-xl font-black italic text-blue-500`}>{nextRank()}</p>
              </div>
           </div>
           <div className="h-5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden p-1.5 border border-black/5 shadow-inner">
              <div className={`h-full rounded-full transition-all duration-1000 ${rankConfig.bg} shadow-lg`} style={{ width: `${getRankProgress()}%` }}></div>
           </div>
           <div className="flex justify-between items-center mt-5">
              <span className={`text-xs font-black tracking-widest ${textColor}`}>{user?.points.toLocaleString()} XP COLLECTED</span>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">{user?.rank === Rank.GRANDMASTER ? 'PEAK EVOLUTION' : 'TARGET: ' + nextRank()}</span>
           </div>
        </div>

        {/* Global Social Matrix */}
        <div className="grid grid-cols-5 gap-4 mb-10">
           {[
             { id: 'instagram', icon: 'fa-instagram', color: 'text-pink-600' },
             { id: 'github', icon: 'fa-github', color: 'text-slate-900 dark:text-white' },
             { id: 'discord', icon: 'fa-discord', color: 'text-indigo-600' },
             { id: 'twitter', icon: 'fa-x-twitter', color: 'text-black dark:text-white' },
             { id: 'telegram', icon: 'fa-telegram', color: 'text-sky-500' },
           ].map(social => {
             const handle = user?.socials[social.id as keyof SocialLinks];
             return (
               <a 
                 key={social.id} 
                 href={handle ? `https://${social.id}.com/${handle}` : '#'}
                 target="_blank"
                 className={`h-16 rounded-[1.8rem] border flex items-center justify-center transition-all ${handle ? 'bg-white dark:bg-white/5 border-slate-100 dark:border-white/10 shadow-xl' : 'opacity-20 grayscale pointer-events-none'} ${borderColor} hover:-translate-y-2 hover:shadow-2xl`}
               >
                  <i className={`fa-brands ${social.icon} text-2xl ${social.color}`}></i>
               </a>
             );
           })}
        </div>

        {/* SUPER COMPLETE EDITING TERMINAL MODAL */}
        {isEditing && (
          <div className="fixed inset-0 z-[110] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-4 sm:p-12 animate-in fade-in duration-500">
            <div className={`w-full max-w-6xl h-[90vh] rounded-[5rem] shadow-[0_0_100px_rgba(37,99,235,0.2)] border flex overflow-hidden ${isDarkMode ? 'bg-[#0f172a] border-slate-800' : 'bg-white border-slate-100'}`}>
               
               {/* Cyberpunk Sidebar */}
               <div className="w-80 border-r border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-black/40 flex flex-col p-10">
                  <div className="mb-14">
                    <div className="flex items-center gap-4 mb-4">
                       <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white text-xl shadow-xl shadow-blue-500/30">
                          <i className="fa-solid fa-terminal"></i>
                       </div>
                       <h3 className={`text-2xl font-black italic uppercase tracking-tighter ${textColor}`}>Core.config</h3>
                    </div>
                    <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.5em]">Network Protocol v3.5</p>
                  </div>
                  
                  <div className="flex-1 space-y-3">
                    {[
                      { id: 'IDENTITY', label: 'Identity Matrix', icon: 'fa-user-tag' },
                      { id: 'VISUALS', label: 'Aesthetic Uplink', icon: 'fa-wand-magic-sparkles' },
                      { id: 'SOCIALS', label: 'Social Gateway', icon: 'fa-share-nodes' },
                      { id: 'PROTOCOLS', label: 'Security & Alerts', icon: 'fa-shield-halved' },
                      { id: 'SECURITY', label: 'Decommission', icon: 'fa-skull' },
                    ].map(tab => (
                      <button 
                        key={tab.id}
                        onClick={() => setActiveEditTab(tab.id as EditTab)}
                        className={`w-full flex items-center gap-5 px-8 py-5 rounded-[1.8rem] text-[11px] font-black uppercase tracking-widest transition-all ${activeEditTab === tab.id ? 'bg-blue-600 text-white shadow-2xl shadow-blue-500/40 translate-x-2' : 'text-slate-400 hover:bg-black/5 dark:hover:bg-white/5'}`}
                      >
                        <i className={`fa-solid ${tab.icon} text-lg`}></i>
                        {tab.label}
                      </button>
                    ))}
                  </div>
                  
                  <div className="mt-auto space-y-4">
                     <div className="p-6 rounded-3xl bg-blue-600/5 border border-blue-500/10">
                        <p className="text-[9px] font-bold text-slate-400 uppercase leading-relaxed">Identity is encrypted via AES-256 cluster. Unauthorized access is impossible.</p>
                     </div>
                     <button onClick={() => setIsEditing(false)} className="w-full py-5 text-[11px] font-black uppercase text-red-500 hover:bg-red-500/10 rounded-2xl transition-all">Abort Reconfig</button>
                  </div>
               </div>

               {/* Main Form Area */}
               <div className="flex-1 flex flex-col overflow-hidden">
                  <div className="flex-1 overflow-y-auto p-14 custom-scrollbar space-y-14">
                     
                     {activeEditTab === 'IDENTITY' && (
                        <div className="animate-in slide-in-from-right-10 duration-700 space-y-12">
                           <div className="grid grid-cols-2 gap-10">
                              <div className="space-y-3">
                                 <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-6">Legal Identification</label>
                                 <input type="text" value={editData.name || ''} onChange={e => setEditData({...editData, name: e.target.value})} className="w-full bg-slate-50 dark:bg-white/5 border-2 border-slate-100 dark:border-white/5 rounded-[2.5rem] px-10 py-6 text-sm font-black focus:border-blue-500 outline-none transition-all dark:text-white" />
                              </div>
                              <div className="space-y-3">
                                 <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-6">Network Nickname</label>
                                 <input type="text" value={editData.nickname || ''} onChange={e => setEditData({...editData, nickname: e.target.value})} className="w-full bg-slate-50 dark:bg-white/5 border-2 border-slate-100 dark:border-white/5 rounded-[2.5rem] px-10 py-6 text-sm font-black focus:border-blue-500 outline-none transition-all dark:text-white" />
                              </div>
                           </div>
                           <div className="space-y-3">
                              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-6">Custom Status Broadcast</label>
                              <input type="text" value={editData.customStatus || ''} onChange={e => setEditData({...editData, customStatus: e.target.value})} placeholder="Broadcast a thought to the community..." className="w-full bg-slate-50 dark:bg-white/5 border-2 border-slate-100 dark:border-white/5 rounded-[2.5rem] px-10 py-6 text-sm font-black focus:border-blue-500 outline-none transition-all dark:text-white" />
                           </div>
                           <div className="grid grid-cols-2 gap-10">
                              <div className="space-y-3">
                                 <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-6">Physical Sector (Location)</label>
                                 <input type="text" value={editData.location || ''} onChange={e => setEditData({...editData, location: e.target.value})} className="w-full bg-slate-50 dark:bg-white/5 border-2 border-slate-100 dark:border-white/5 rounded-[2.5rem] px-10 py-6 text-sm font-black focus:border-blue-500 outline-none transition-all dark:text-white" />
                              </div>
                              <div className="space-y-3">
                                 <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-6">Deployment Date (Birthday)</label>
                                 <input type="date" value={editData.birthday || ''} onChange={e => setEditData({...editData, birthday: e.target.value})} className="w-full bg-slate-50 dark:bg-white/5 border-2 border-slate-100 dark:border-white/5 rounded-[2.5rem] px-10 py-6 text-sm font-black focus:border-blue-500 outline-none transition-all dark:text-white" />
                              </div>
                           </div>
                           <div className="space-y-3">
                              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-6">Detailed Intelligence Bio</label>
                              <textarea value={editData.bio || ''} onChange={e => setEditData({...editData, bio: e.target.value})} rows={5} className="w-full bg-slate-50 dark:bg-white/5 border-2 border-slate-100 dark:border-white/5 rounded-[3.5rem] px-10 py-8 text-sm font-medium focus:border-blue-500 outline-none transition-all resize-none dark:text-white" placeholder="Input bio data for node identification..." />
                           </div>
                        </div>
                     )}

                     {activeEditTab === 'VISUALS' && (
                        <div className="animate-in slide-in-from-right-10 duration-700 space-y-12">
                           <div className="space-y-6">
                              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] ml-6">Avatar Binary Source</label>
                              <div className="flex gap-10 items-center bg-slate-50 dark:bg-white/5 p-8 rounded-[3.5rem] border-2 border-slate-100 dark:border-white/5">
                                 <img src={editData.avatar} className="w-32 h-32 rounded-[2.5rem] object-cover border-4 border-white dark:border-slate-800 shadow-2xl" />
                                 <div className="flex-1 space-y-4">
                                    <input type="text" value={editData.avatar || ''} onChange={e => setEditData({...editData, avatar: e.target.value})} className="w-full bg-white dark:bg-black/40 border border-slate-200 dark:border-white/10 rounded-2xl px-6 py-4 text-xs font-black outline-none focus:border-blue-500 dark:text-white" placeholder="https://..." />
                                    <p className="text-[9px] font-bold text-slate-400 px-2 uppercase tracking-widest">Provide a direct high-quality link for the uplink.</p>
                                 </div>
                              </div>
                           </div>
                           <div className="space-y-6">
                              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] ml-6">Wide-range Banner Uplink</label>
                              <div className="space-y-6 bg-slate-50 dark:bg-white/5 p-8 rounded-[3.5rem] border-2 border-slate-100 dark:border-white/5">
                                 <img src={editData.banner} className="w-full h-44 rounded-[2.5rem] object-cover border-4 border-white dark:border-slate-800 shadow-2xl" />
                                 <input type="text" value={editData.banner || ''} onChange={e => setEditData({...editData, banner: e.target.value})} className="w-full bg-white dark:bg-black/40 border border-slate-200 dark:border-white/10 rounded-2xl px-6 py-4 text-xs font-black outline-none focus:border-blue-500 dark:text-white" placeholder="https://..." />
                                 <p className="text-[9px] font-bold text-slate-400 px-2 uppercase tracking-widest text-center">Recommend 1920x1080 resolution for optimal cluster rendering.</p>
                              </div>
                           </div>
                        </div>
                     )}

                     {activeEditTab === 'SOCIALS' && (
                        <div className="animate-in slide-in-from-right-10 duration-700 space-y-8">
                           <div className="bg-blue-600/5 p-8 rounded-[3rem] border-2 border-blue-500/10 mb-6">
                              <p className="text-[10px] font-black text-blue-600 uppercase tracking-[0.3em] text-center italic">Link your matrix handles to sync with the community.</p>
                           </div>
                           {[
                             { id: 'instagram', label: 'Instagram Pulse', icon: 'fa-instagram', color: 'text-pink-600' },
                             { id: 'github', icon: 'fa-github', label: 'GitHub Repository', color: 'text-slate-900 dark:text-white' },
                             { id: 'discord', icon: 'fa-discord', label: 'Discord Communication', color: 'text-indigo-600' },
                             { id: 'twitter', icon: 'fa-x-twitter', label: 'X Network', color: 'text-black dark:text-white' },
                             { id: 'telegram', icon: 'fa-telegram', label: 'Telegram Signal', color: 'text-sky-500' },
                           ].map(social => (
                             <div key={social.id} className="space-y-3">
                                <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-8">{social.label}</label>
                                <div className="flex items-center gap-6 bg-slate-50 dark:bg-white/5 border-2 border-slate-100 dark:border-white/10 rounded-[2.5rem] px-10 py-5 group focus-within:border-blue-500 transition-all">
                                   <i className={`fa-brands ${social.icon} text-2xl ${social.color} group-hover:scale-125 transition-transform`}></i>
                                   <input 
                                     type="text" 
                                     value={editData.socials?.[social.id as keyof SocialLinks] || ''} 
                                     onChange={e => updateSocial(social.id as keyof SocialLinks, e.target.value)}
                                     placeholder={`username...`}
                                     className="bg-transparent flex-1 text-base font-black outline-none dark:text-white" 
                                   />
                                </div>
                             </div>
                           ))}
                        </div>
                     )}

                     {activeEditTab === 'PROTOCOLS' && (
                        <div className="animate-in slide-in-from-right-10 duration-700 space-y-16">
                           {/* Notif Prefs */}
                           <div className="space-y-10">
                              <h4 className="text-xl font-black text-blue-500 uppercase tracking-[0.5em] ml-4 italic">Signal Protocols</h4>
                              <div className="grid grid-cols-1 gap-6">
                                 {[
                                   { id: 'comments', label: 'Interaction Signals', icon: 'fa-comment-dots', desc: 'New comments and replies in forum threads.' },
                                   { id: 'updates', label: 'Artifact Updates', icon: 'fa-download', desc: 'Alerts for new versions and patches of installed apps.' },
                                   { id: 'system', label: 'Infrastructure Status', icon: 'fa-bolt', desc: 'Critical system maintenance and tier evolution info.' },
                                   { id: 'messages', label: 'Secure Transmissions', icon: 'fa-envelope-open-text', desc: 'Encrypted messages from authorized staff or peers.' },
                                 ].map(pref => (
                                   <div key={pref.id} className="flex items-center justify-between p-8 bg-slate-50 dark:bg-white/5 rounded-[3rem] border-2 border-transparent hover:border-blue-500/20 transition-all">
                                      <div className="flex items-center gap-6">
                                         <div className="w-14 h-14 bg-white dark:bg-slate-800 rounded-3xl flex items-center justify-center text-blue-500 shadow-xl">
                                            <i className={`fa-solid ${pref.icon} text-xl`}></i>
                                         </div>
                                         <div>
                                            <span className="text-sm font-black uppercase italic dark:text-white tracking-tight">{pref.label}</span>
                                            <p className="text-[10px] font-medium text-slate-400 mt-1">{pref.desc}</p>
                                         </div>
                                      </div>
                                      <button 
                                        onClick={() => updateNestedPref(pref.id as keyof NotificationPreferences, !editData.notificationPreferences?.[pref.id as keyof NotificationPreferences])}
                                        className={`w-16 h-8 rounded-full relative transition-all duration-500 ${editData.notificationPreferences?.[pref.id as keyof NotificationPreferences] ? 'bg-blue-600 shadow-[0_0_20px_rgba(37,99,235,0.4)]' : 'bg-slate-300'}`}
                                      >
                                         <div className={`absolute top-1 w-6 h-6 rounded-full bg-white shadow-lg transition-all duration-500 ${editData.notificationPreferences?.[pref.id as keyof NotificationPreferences] ? 'left-9' : 'left-1'}`}></div>
                                      </button>
                                   </div>
                                 ))}
                              </div>
                           </div>

                           {/* Privacy Protocols */}
                           <div className="space-y-10">
                              <h4 className="text-xl font-black text-emerald-500 uppercase tracking-[0.5em] ml-4 italic">Privacy Matrices</h4>
                              <div className="grid grid-cols-1 gap-6">
                                 {[
                                   { id: 'showActivity', label: 'Live Uplink Presence', icon: 'fa-signal', desc: 'Display your online status to the community.' },
                                   { id: 'privateProfile', label: 'Stealth Protocol', icon: 'fa-user-secret', desc: 'Hide your node data from unauthorized searches.' },
                                   { id: 'showRank', label: 'Visible Tier Badge', icon: 'fa-trophy', desc: 'Allow others to see your current achievement tier.' },
                                   { id: 'showSocials', label: 'Global Social Link', icon: 'fa-share-nodes', desc: 'Enable visibility for your linked matrix handles.' },
                                 ].map(priv => (
                                   <div key={priv.id} className="flex items-center justify-between p-8 bg-slate-50 dark:bg-white/5 rounded-[3rem] border-2 border-transparent hover:border-emerald-500/20 transition-all">
                                      <div className="flex items-center gap-6">
                                         <div className="w-14 h-14 bg-white dark:bg-slate-800 rounded-3xl flex items-center justify-center text-emerald-500 shadow-xl">
                                            <i className={`fa-solid ${priv.icon} text-xl`}></i>
                                         </div>
                                         <div>
                                            <span className="text-sm font-black uppercase italic dark:text-white tracking-tight">{priv.label}</span>
                                            <p className="text-[10px] font-medium text-slate-400 mt-1">{priv.desc}</p>
                                         </div>
                                      </div>
                                      <button 
                                        onClick={() => updatePrivacy(priv.id as keyof PrivacySettings, !editData.privacy?.[priv.id as keyof PrivacySettings])}
                                        className={`w-16 h-8 rounded-full relative transition-all duration-500 ${editData.privacy?.[priv.id as keyof PrivacySettings] ? 'bg-emerald-600 shadow-[0_0_20px_rgba(16,185,129,0.4)]' : 'bg-slate-300'}`}
                                      >
                                         <div className={`absolute top-1 w-6 h-6 rounded-full bg-white shadow-lg transition-all duration-500 ${editData.privacy?.[priv.id as keyof PrivacySettings] ? 'left-9' : 'left-1'}`}></div>
                                      </button>
                                   </div>
                                 ))}
                              </div>
                           </div>
                        </div>
                     )}

                     {activeEditTab === 'SECURITY' && (
                        <div className="animate-in zoom-in duration-500 flex items-center justify-center h-full">
                           <div className="p-16 bg-red-600/5 border-4 border-dashed border-red-500/20 rounded-[5rem] text-center max-w-xl">
                              <i className="fa-solid fa-skull-crossbones text-7xl text-red-500 mb-10 animate-pulse"></i>
                              <h3 className="text-2xl font-black text-red-600 uppercase mb-6 tracking-tighter italic">Total Decommissioning</h3>
                              <p className="text-sm text-slate-400 mb-12 font-medium leading-relaxed italic">Warning: Initiating node termination will permanently wipe all collected XP, rank data, VIP/PLUS authorization, and community artifacts from the CHIKIMOD cluster. This action is irreversible.</p>
                              <button className="px-16 py-7 bg-red-600 text-white rounded-[3rem] text-xs font-black uppercase tracking-[0.3em] shadow-[0_20px_50px_rgba(220,38,38,0.3)] active:scale-90 transition-all">Deactivate Protocol Now</button>
                           </div>
                        </div>
                     )}
                     
                  </div>

                  {/* Sync Action Footer */}
                  <div className={`p-10 bg-white dark:bg-black/40 border-t border-slate-100 dark:border-white/5 flex gap-6`}>
                     <button onClick={() => setIsEditing(false)} className="flex-1 py-7 text-[12px] font-black uppercase tracking-[0.4em] text-slate-400 hover:text-slate-600 transition-colors">Cancel Uplink</button>
                     <button onClick={handleSaveProfile} className="flex-[2] bg-blue-600 text-white py-7 rounded-[3rem] text-[12px] font-black uppercase tracking-[0.6em] shadow-[0_20px_60px_rgba(37,99,235,0.4)] hover:bg-blue-700 active:scale-95 transition-all">Sync Cluster Node</button>
                  </div>
               </div>
               
            </div>
          </div>
        )}

        {/* Regular Profile Overview Sections */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-8">
           <div className={`rounded-[3.5rem] p-10 border shadow-2xl transition-all duration-500 ${cardBg} ${borderColor}`}>
              <h3 className={`text-[10px] font-black uppercase tracking-[0.4em] mb-10 ${subTextColor}`}>Cluster Intelligence</h3>
              <div className="space-y-8">
                 <div className="flex justify-between items-center border-b border-slate-50 dark:border-white/5 pb-6">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Partner</p>
                    <p className={`text-sm font-black italic flex items-center gap-2 ${textColor}`}>
                       <i className="fa-solid fa-heart text-pink-500"></i> {user?.partnerName || 'None'}
                    </p>
                 </div>
                 <div className="flex justify-between items-center border-b border-slate-50 dark:border-white/5 pb-6">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Growth Level</p>
                    <div className="flex items-center gap-2">
                       <i className="fa-solid fa-seedling text-emerald-500"></i>
                       <p className={`text-sm font-black italic ${textColor}`}>{user?.coupleFlowerLevel}% Synced</p>
                    </div>
                 </div>
                 <div className="flex justify-between items-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Node Uptime</p>
                    <p className={`text-sm font-black italic ${textColor}`}>324 Days</p>
                 </div>
              </div>
           </div>

           <div className={`rounded-[3.5rem] p-10 border shadow-2xl transition-all duration-500 ${cardBg} ${borderColor}`}>
              <h3 className={`text-[10px] font-black uppercase tracking-[0.4em] mb-10 ${subTextColor}`}>Biography Signal</h3>
              <p className={`text-sm font-medium italic leading-[1.8] ${textColor}`}>
                {user?.bio || 'This node operates in stealth mode. No intelligence data broadcasted yet.'}
              </p>
              <div className="mt-8 pt-8 border-t border-slate-50 dark:border-white/5 flex gap-4">
                 <div className="px-4 py-2 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5">
                    <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest">Developer Class</span>
                 </div>
                 <div className="px-4 py-2 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5">
                    <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">Certified Modder</span>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
