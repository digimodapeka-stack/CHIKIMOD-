
import React from 'react';
import { Rank } from '../types';
import { RANK_CONFIG } from '../constants';

interface RankBadgeProps {
  rank: Rank;
  showText?: boolean;
}

const RankBadge: React.FC<RankBadgeProps> = ({ rank, showText = true }) => {
  const config = RANK_CONFIG[rank];
  
  return (
    <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full ${config.bg} text-white text-[10px] font-bold uppercase tracking-wider shadow-sm`}>
      <i className={config.icon}></i>
      {showText && <span>{rank}</span>}
    </div>
  );
};

export default RankBadge;
