
import React, { useState, useEffect, useRef } from 'react';

interface SplashScreenProps {
  onUnlock: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onUnlock }) => {
  const [progress, setProgress] = useState(0);
  const [isScanning, setIsScanning] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const timerRef = useRef<number | null>(null);

  const startScan = () => {
    setIsScanning(true);
    timerRef.current = window.setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          if (timerRef.current) clearInterval(timerRef.current);
          handleSuccess();
          return 100;
        }
        return prev + 2;
      });
    }, 30);
  };

  const stopScan = () => {
    if (!isSuccess) {
      setIsScanning(false);
      setProgress(0);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const handleSuccess = () => {
    setIsSuccess(true);
    setTimeout(() => {
      onUnlock();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-black flex flex-col items-center justify-center overflow-hidden">
      {/* Tech Background Grid */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ 
        backgroundImage: 'radial-gradient(#3b82f6 1px, transparent 1px)', 
        backgroundSize: '30px 30px' 
      }}></div>

      <div className="relative z-10 flex flex-col items-center text-center px-10">
        <div className="mb-12 animate-in fade-in zoom-in duration-1000">
          <div className="w-24 h-24 bg-blue-600 rounded-[2.5rem] flex items-center justify-center text-white text-5xl mb-6 mx-auto shadow-[0_0_50px_rgba(37,99,235,0.4)]">
            <i className="fa-solid fa-bolt"></i>
          </div>
          <h1 className="text-4xl font-black text-white italic uppercase tracking-tighter">CHIKIMOD</h1>
          <p className="text-blue-500 text-[10px] font-black uppercase tracking-[0.6em] mt-3">Security Protocol</p>
        </div>

        {/* Fingerprint Scanner Area */}
        <div className="relative mt-10">
          {/* Animated Ripples */}
          {isScanning && !isSuccess && (
            <>
              <div className="ripple-effect w-32 h-32 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
              <div className="ripple-effect w-32 h-32 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" style={{ animationDelay: '0.5s' }}></div>
            </>
          )}

          <button
            onMouseDown={startScan}
            onMouseUp={stopScan}
            onMouseLeave={stopScan}
            onTouchStart={startScan}
            onTouchEnd={stopScan}
            className={`relative w-32 h-40 rounded-[3rem] border-4 transition-all duration-500 flex flex-col items-center justify-center overflow-hidden active:scale-90 ${
              isSuccess 
                ? 'bg-emerald-500 border-emerald-400 shadow-[0_0_60px_rgba(16,185,129,0.5)]' 
                : isScanning 
                  ? 'bg-blue-600/20 border-blue-500 shadow-[0_0_40px_rgba(59,130,246,0.3)]' 
                  : 'bg-white/5 border-white/20'
            }`}
          >
            {isScanning && !isSuccess && <div className="scanner-line"></div>}
            
            <i className={`fa-solid ${isSuccess ? 'fa-check text-5xl' : 'fa-fingerprint text-6xl'} transition-all duration-300 ${
              isSuccess ? 'text-white' : isScanning ? 'text-blue-500' : 'text-white/30'
            }`}></i>
            
            {progress > 0 && !isSuccess && (
              <div className="absolute bottom-0 left-0 w-full bg-blue-500/30" style={{ height: `${progress}%` }}></div>
            )}
          </button>
          
          <div className="mt-8">
            <p className={`text-[11px] font-black uppercase tracking-[0.3em] transition-all duration-500 ${
              isSuccess ? 'text-emerald-500' : isScanning ? 'text-blue-400' : 'text-slate-500'
            }`}>
              {isSuccess ? 'ACCESS GRANTED' : isScanning ? 'SCANNING BIOMETRICS...' : 'HOLD TO AUTHENTICATE'}
            </p>
          </div>
        </div>
      </div>

      {/* Version & Credits */}
      <div className="absolute bottom-12 text-center w-full px-10">
        <p className="text-white/20 text-[9px] font-bold uppercase tracking-[0.4em]">Node ID: 0xFF1293 | Cluster v3.5.0</p>
      </div>
    </div>
  );
};

export default SplashScreen;
