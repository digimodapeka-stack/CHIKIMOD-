import React, { useState } from 'react';
import { NavItem, AppData, User } from '../types';

interface StoreProps {
  apps: AppData[];
  onAction: () => void;
  onNotifyBellClick: () => void;
  unreadCount: number;
  onReport: (id: string, type: 'APP', name: string) => void;
  isVIP: boolean;
  onNavigate: (tab: NavItem) => void;
  isDarkMode: boolean;
  user: User;
}

const Store: React.FC<StoreProps> = ({ apps, onAction, onNotifyBellClick, unreadCount, onReport, isVIP, onNavigate, isDarkMode, user }) => {
  const [installing, setInstalling] = useState<string | null>(null);
  const [downloaded, setDownloaded] = useState<string[]>([]);
  const [progress, setProgress] = useState<number>(0);
  const [selectedApp, setSelectedApp] = useState<AppData | null>(null);
  const [activeCategory, setActiveCategory] = useState('Semua');

  const categories = ['Semua', 'Aplikasi', 'Game', 'Premium', 'Tools Hub'];

  // Enhanced featured logic
  const featuredApps = apps.slice(0, 5);
  const trendingApps = [...apps].sort((a, b) => parseInt(b.downloads) - parseInt(a.downloads)).slice(0, 6);

  const filteredApps = apps.filter(app => {
    if (activeCategory === 'Semua') return true;
    if (activeCategory === 'Aplikasi') return app.category !== 'Action';
    if (activeCategory === 'Game') return app.category === 'Action';
    if (activeCategory === 'Premium') return app.isExclusive === 'VIP' || app.isExclusive === 'PLUS';
    return true;
  });

  const handleInstall = (appId: string) => {
    if (installing || downloaded.includes(appId)) return;
    setInstalling(appId);
    setProgress(0);
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + Math.floor(Math.random() * 20) + 5;
      });
    }, 120);
    setTimeout(() => {
      setInstalling(null);
      setDownloaded(prev => [...prev, appId]);
      onAction(); 
    }, 1800);
  };

  // Fix: Defined missing subTextColor used in line 129, 162, and 333.
  const textColor = isDarkMode ? 'text-white' : 'text-slate-900';
  const subTextColor = isDarkMode ? 'text-slate-400' : 'text-slate-500';
  const cardBg = isDarkMode ? 'bg-slate-900' : 'bg-white';
  const borderColor = isDarkMode ? 'border-slate-800' : 'border-slate-100';

  return (
    <div className={`pb-32 transition-colors duration-500 min-h-screen ${isDarkMode ? 'bg-slate-950' : 'bg-[#f8faff]'}`}>
      {/* Premium Navigation Header */}
      <header className={`sticky top-0 z-[40] px-6 pt-8 pb-4 transition-all ${isDarkMode ? 'bg-slate-950/90 backdrop-blur-xl' : 'bg-white/90 backdrop-blur-xl'}`}>
         <div className="flex items-center justify-between mb-6">
            <h1 className={`text-2xl font-black italic uppercase tracking-tighter ${textColor}`}>CHIKIMOD <span className="text-blue-600">STORE</span></h1>
            <div className="flex items-center gap-3">
               <div className="flex items-center gap-2 bg-orange-500/10 px-4 py-1.5 rounded-full border border-orange-500/20">
                  <span className="text-orange-600 text-[11px] font-black">{user.streakCount}D</span>
                  <i className="fa-solid fa-fire text-orange-600 text-xs animate-pulse"></i>
               </div>
               <button onClick={onNotifyBellClick} className="relative w-10 h-10 rounded-full bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-500 active:scale-90 transition-all">
                <i className="fa-solid fa-bell"></i>
                {unreadCount > 0 && <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-600 rounded-full border-2 border-white"></span>}
               </button>
            </div>
         </div>

         <div className={`flex items-center gap-4 px-6 py-4 rounded-2xl shadow-sm border transition-all mb-6 ${isDarkMode ? 'bg-slate-900/50 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>
            <i className="fa-solid fa-magnifying-glass text-slate-400"></i>
            <input type="text" placeholder="Search verified mods..." className="bg-transparent flex-1 text-sm focus:outline-none font-bold placeholder:text-slate-400" />
            <i className="fa-solid fa-sliders text-slate-400 cursor-pointer"></i>
         </div>

         <div className="flex gap-4 px-1 overflow-x-auto no-scrollbar scroll-smooth">
            {categories.map((label) => (
               <button 
                key={label} 
                onClick={() => setActiveCategory(label)}
                className={`px-6 py-2.5 rounded-2xl text-[10px] font-black whitespace-nowrap transition-all border ${
                  activeCategory === label 
                  ? 'bg-black text-white border-black shadow-xl shadow-black/10 scale-105' 
                  : (isDarkMode ? 'bg-slate-900 text-slate-400 border-slate-800' : 'bg-white text-slate-500 border-slate-100')
                }`}
               >
                  {label}
               </button>
            ))}
         </div>
      </header>

      <div className="px-6 mt-6 space-y-12 animate-in fade-in duration-700">
         
         {/* Featured Carousel - "Super Complete" Styling */}
         <section>
            <div className="flex justify-between items-end mb-6 px-2">
              <h2 className={`text-2xl font-black italic uppercase tracking-tighter ${textColor}`}>Elite Recommendations ✨</h2>
            </div>
            <div className="flex gap-6 overflow-x-auto no-scrollbar pb-6 px-2 scroll-smooth">
               {featuredApps.map(app => (
                  <div 
                    key={`featured-${app.id}`} 
                    onClick={() => setSelectedApp(app)}
                    className={`flex-shrink-0 w-[320px] rounded-[3.5rem] border overflow-hidden transition-all active:scale-95 cursor-pointer shadow-2xl ${cardBg} ${borderColor} hover:border-blue-500/50 group`}
                  >
                     <div className="relative h-44">
                        <img src={app.screenshots?.[0] || 'https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?auto=format&fit=crop&q=80&w=1000'} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                        <div className="absolute bottom-4 left-6 flex items-center gap-4">
                           <img src={app.icon} className="w-16 h-16 rounded-[1.5rem] shadow-2xl border-2 border-white/20 object-cover" alt="" />
                           <div className="flex-1 min-w-0">
                              <h4 className="font-black text-white text-lg truncate italic leading-none">{app.name}</h4>
                              <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest">{app.category}</span>
                           </div>
                        </div>
                     </div>
                     <div className="p-6">
                        <p className={`text-[11px] font-medium ${subTextColor} line-clamp-2 italic mb-4`}>
                           {app.description}
                        </p>
                        <div className="flex items-center justify-between pt-4 border-t border-slate-50 dark:border-white/5">
                           <div className="flex items-center gap-2">
                              <i className="fa-solid fa-star text-amber-500 text-[10px]"></i>
                              <span className={`text-[11px] font-black ${textColor}`}>{app.rating || '5.0'}</span>
                           </div>
                           <span className="text-[9px] font-black text-emerald-600 uppercase tracking-[0.2em] bg-emerald-50 dark:bg-emerald-500/10 px-4 py-1.5 rounded-full">Editor's Choice</span>
                        </div>
                     </div>
                  </div>
               ))}
            </div>
         </section>

         {/* Promo Banner */}
         <section className="relative h-56 rounded-[4rem] overflow-hidden group shadow-2xl border-4 border-white dark:border-slate-800">
            <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=1000" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[10s]" alt="Banner" />
            <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 via-blue-900/40 to-transparent flex flex-col justify-center px-12">
               <div className="bg-white/10 backdrop-blur-md w-fit px-4 py-1.5 rounded-full border border-white/20 mb-4">
                  <span className="text-white text-[9px] font-black uppercase tracking-[0.3em]">PRO SERVICE ACTIVE</span>
               </div>
               <h3 className="text-white text-4xl font-black italic uppercase leading-none tracking-tighter">CHIKIMOD <span className="text-blue-400">PLUS</span></h3>
               <p className="text-white/60 text-[10px] mt-4 font-black uppercase tracking-[0.3em]">Unlock Supernode Access Today</p>
               <button onClick={() => onNavigate('VIP_HUB')} className="mt-6 bg-white text-black w-fit px-8 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-blue-500 hover:text-white transition-all active:scale-95">Upgrade Hub</button>
            </div>
         </section>

         {/* Trending Now */}
         <section>
            <div className="flex justify-between items-end mb-8 px-2">
              <h2 className={`text-2xl font-black italic uppercase tracking-tighter ${textColor}`}>Trending Matrix 🔥</h2>
              <button className={`text-[10px] font-black ${subTextColor} uppercase tracking-widest hover:text-blue-600 transition-colors`}>View Global</button>
            </div>
            <div className="flex gap-5 overflow-x-auto no-scrollbar pb-6 scroll-smooth">
               {trendingApps.map((app, i) => (
                  <div 
                    key={`trending-${app.id}`} 
                    onClick={() => setSelectedApp(app)}
                    className={`flex-shrink-0 w-44 p-6 rounded-[3.5rem] border flex flex-col items-center transition-all active:scale-95 cursor-pointer ${cardBg} ${borderColor} hover:shadow-2xl hover:-translate-y-2`}
                  >
                     <div className="relative mb-5">
                        <img src={app.icon} className="w-28 h-28 rounded-[2.5rem] shadow-xl object-cover border-4 border-white/10" alt="" />
                        <div className="absolute -top-3 -left-3 w-10 h-10 bg-black text-white rounded-full border-4 border-white flex items-center justify-center text-sm font-black italic">
                           {i + 1}
                        </div>
                     </div>
                     <h4 className={`font-black text-[13px] text-center truncate w-full italic mb-1 ${textColor}`}>{app.name}</h4>
                     <p className="text-[9px] font-black text-blue-600 uppercase tracking-[0.2em]">{app.category}</p>
                     <div className="flex items-center gap-1.5 mt-4 py-1.5 px-4 bg-slate-50 dark:bg-white/5 rounded-full">
                        <i className="fa-solid fa-star text-amber-500 text-[9px]"></i>
                        <span className={`font-black text-[10px] ${textColor}`}>{app.rating || '5.0'}</span>
                     </div>
                  </div>
               ))}
            </div>
         </section>

         {/* Full Archive */}
         <section className="pb-12">
            <div className="flex justify-between items-end mb-8 px-2">
              <h2 className={`text-2xl font-black italic uppercase tracking-tighter ${textColor}`}>
                {activeCategory === 'Semua' ? 'Verified Cluster' : activeCategory}
              </h2>
            </div>
            <div className="grid grid-cols-1 gap-5">
               {filteredApps.map((app, index) => (
                  <div 
                    key={app.id} 
                    onClick={() => setSelectedApp(app)}
                    className={`p-6 rounded-[3rem] border flex items-center gap-6 transition-all active:scale-95 cursor-pointer ${cardBg} ${borderColor} hover:border-blue-600 hover:shadow-xl group`}
                  >
                     <div className="relative">
                        <img src={app.icon} className="w-20 h-20 rounded-[1.8rem] shadow-2xl object-cover border-2 border-white dark:border-slate-800" alt="" />
                        <div className="absolute -top-2 -right-2 w-7 h-7 bg-emerald-500 rounded-full border-4 border-white dark:border-slate-800 flex items-center justify-center shadow-lg">
                           <i className="fa-solid fa-check text-white text-[10px]"></i>
                        </div>
                     </div>
                     <div className="flex-1 min-w-0">
                        <h4 className={`font-black text-lg truncate italic leading-none group-hover:text-blue-600 transition-colors ${textColor}`}>{app.name}</h4>
                        <div className="flex items-center gap-3 mt-2">
                           <span className="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em]">{app.category}</span>
                           <span className="text-[10px] text-slate-400 font-black tracking-widest">• {app.size}</span>
                        </div>
                        <div className="flex items-center gap-4 mt-3">
                           <div className="flex items-center gap-1.5 text-amber-500 text-[11px]">
                              <i className="fa-solid fa-star"></i>
                              <span className={`font-black ${textColor}`}>{app.rating || '5.0'}</span>
                           </div>
                           <span className="text-[9px] font-black text-emerald-600 uppercase tracking-[0.2em] bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-100 dark:border-emerald-500/10">Verified Mod</span>
                        </div>
                     </div>
                     <button className="w-14 h-14 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-black flex items-center justify-center shadow-xl group-hover:scale-110 transition-all active:rotate-12">
                        <i className="fa-solid fa-cloud-arrow-down text-lg"></i>
                     </button>
                  </div>
               ))}
            </div>
         </section>
      </div>

      {/* App Detail Modal */}
      {selectedApp && (
         <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-3xl flex items-end sm:items-center justify-center p-0 sm:p-8 animate-in fade-in duration-300">
            <div className={`w-full max-w-2xl max-h-[98vh] rounded-t-[5rem] sm:rounded-[5rem] overflow-y-auto no-scrollbar transition-all ${cardBg} shadow-2xl relative border-t-[14px] border-blue-600`}>
               
               <div className="p-10 pb-20">
                 <div className="flex justify-between items-start mb-12">
                    <div className="flex gap-8 items-center">
                       <img src={selectedApp.icon} className="w-32 h-32 rounded-[3rem] shadow-2xl object-cover border-4 border-white dark:border-slate-800" alt="" />
                       <div>
                          <h2 className={`text-4xl font-black italic uppercase leading-tight tracking-tighter ${textColor}`}>{selectedApp.name}</h2>
                          <p className="text-[11px] font-black text-blue-600 uppercase tracking-[0.4em] mt-3">Dev: {selectedApp.developer || 'CHIKIMOD Labs'}</p>
                          <div className="flex items-center gap-3 mt-5">
                             <span className="bg-emerald-600 text-white text-[9px] font-black px-4 py-2 rounded-full flex items-center gap-2 shadow-lg">
                                <i className="fa-solid fa-shield-check"></i> MOD SECURE
                             </span>
                             {selectedApp.isExclusive && (
                               <span className="bg-black text-white text-[9px] font-black px-4 py-2 rounded-full uppercase tracking-widest shadow-lg italic">
                                 {selectedApp.isExclusive} ONLY
                               </span>
                             )}
                          </div>
                       </div>
                    </div>
                    <button onClick={() => setSelectedApp(null)} className="w-14 h-14 bg-slate-100 dark:bg-white/10 rounded-full flex items-center justify-center text-slate-500 dark:text-white text-3xl hover:bg-red-600 hover:text-white transition-all active:scale-90">
                       <i className="fa-solid fa-xmark"></i>
                    </button>
                 </div>

                 {/* Detailed Stats */}
                 <div className={`grid grid-cols-4 gap-6 mb-12 border-y-2 py-10 ${borderColor}`}>
                    <div className="text-center">
                       <p className={`text-2xl font-black ${textColor}`}>{selectedApp.rating}<i className="fa-solid fa-star text-amber-500 text-xs ml-2"></i></p>
                       <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.3em] mt-2">Rating</p>
                    </div>
                    <div className={`text-center border-l-2 ${borderColor}`}>
                       <p className={`text-2xl font-black ${textColor}`}>{selectedApp.size}</p>
                       <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.3em] mt-2">Space</p>
                    </div>
                    <div className={`text-center border-l-2 ${borderColor}`}>
                       <p className={`text-2xl font-black ${textColor}`}>{selectedApp.downloads}</p>
                       <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.3em] mt-2">Nodes</p>
                    </div>
                    <div className={`text-center border-l-2 ${borderColor}`}>
                       <p className={`text-sm font-black truncate px-2 pt-2 ${textColor}`}>{selectedApp.version || 'v1.0'}</p>
                       <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.3em] mt-2">Ver</p>
                    </div>
                 </div>

                 <button 
                  onClick={() => handleInstall(selectedApp.id)} 
                  disabled={!!installing}
                  className={`w-full py-8 rounded-[3rem] text-white font-black uppercase tracking-[0.5em] text-[12px] shadow-2xl transition-all active:scale-95 mb-14 ${installing === selectedApp.id ? 'bg-slate-400' : 'bg-slate-900 shadow-slate-900/20 hover:bg-black'}`}
                 >
                    {installing === selectedApp.id ? (
                      <div className="flex items-center justify-center gap-4">
                        <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                        <span>SYNCING ARCHIVE... {progress}%</span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-4">
                        <i className="fa-solid fa-cloud-arrow-down text-xl"></i>
                        <span>INITIATE INSTALL</span>
                      </div>
                    )}
                 </button>

                 {/* Visual Preview */}
                 {selectedApp.screenshots && (
                   <div className="mb-14">
                      <h3 className={`text-[11px] font-black uppercase tracking-[0.4em] mb-8 flex items-center gap-3 ${textColor}`}>
                        <i className="fa-solid fa-images text-blue-600"></i> Interface Node Gallery
                      </h3>
                      <div className="flex gap-6 overflow-x-auto no-scrollbar pb-8 px-2">
                        {selectedApp.screenshots.map((shot, i) => (
                          <img key={i} src={shot} className="w-56 h-96 rounded-[3.5rem] object-cover shadow-2xl border-4 border-white dark:border-slate-800 flex-shrink-0 hover:scale-105 transition-transform cursor-zoom-in" alt="" />
                        ))}
                      </div>
                   </div>
                 )}

                 {/* Modification Features */}
                 {selectedApp.modFeatures && (
                    <div className={`mb-14 p-10 rounded-[4rem] border-2 ${isDarkMode ? 'bg-blue-600/5 border-blue-500/10' : 'bg-blue-50 border-blue-100'}`}>
                       <h3 className="text-blue-600 text-[11px] font-black uppercase tracking-[0.4em] mb-10 flex items-center gap-3">
                         <i className="fa-solid fa-wand-magic-sparkles animate-pulse"></i> Mod Capabilities
                       </h3>
                       <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                          {selectedApp.modFeatures.map((feat, i) => (
                            <div key={i} className="flex items-center gap-4 group">
                               <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg group-hover:rotate-12 transition-transform">
                                 <i className="fa-solid fa-check text-sm"></i>
                               </div>
                               <span className={`text-[14px] font-black italic uppercase tracking-tight ${textColor}`}>{feat}</span>
                            </div>
                          ))}
                       </div>
                    </div>
                 )}

                 {/* App Intelligence Metadata */}
                 <div className={`p-10 rounded-[4.5rem] border-2 mb-16 ${isDarkMode ? 'bg-slate-900/50 border-white/5' : 'bg-slate-50 border-slate-100'}`}>
                    <h3 className={`text-[11px] font-black uppercase tracking-[0.5em] mb-12 ${subTextColor}`}>Metadata Summary</h3>
                    <div className="grid grid-cols-2 gap-x-12 gap-y-12">
                       <div>
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Cluster ID</p>
                          <p className={`text-sm font-black truncate tracking-tight ${textColor}`}>{selectedApp.packageName || 'com.chikimod.app'}</p>
                       </div>
                       <div>
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Requirement</p>
                          <p className={`text-sm font-black tracking-tight ${textColor}`}>{selectedApp.minAndroid || 'Android 7.0+'}</p>
                       </div>
                       <div>
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Last Update</p>
                          <p className={`text-sm font-black tracking-tight ${textColor}`}>{selectedApp.updatedAt || 'Real-time'}</p>
                       </div>
                       <div>
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Architecture</p>
                          <p className={`text-sm font-black tracking-tight ${textColor}`}>ARM64 Optimized</p>
                       </div>
                    </div>
                 </div>

               </div>
            </div>
         </div>
      )}
    </div>
  );
};

export default Store;