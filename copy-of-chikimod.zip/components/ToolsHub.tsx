
import React, { useState } from 'react';
import { Tool } from '../types';

const MOCK_TOOLS: Tool[] = [
  { id: 't1', name: 'TikTok Downloader', description: 'Download TikTok videos without watermark instantly.', icon: 'fa-brands fa-tiktok', type: 'DOWNLOADER', isPremium: false },
  { id: 't2', name: 'YouTube Pro', description: 'Convert YouTube videos to High Quality MP3 or MP4.', icon: 'fa-brands fa-youtube', type: 'DOWNLOADER', isPremium: true },
  { id: 't3', name: 'InstaSave', description: 'Save Instagram Stories, Reels, and Posts in one click.', icon: 'fa-brands fa-instagram', type: 'DOWNLOADER', isPremium: false },
  { id: 't4', name: 'Spotify DL', description: 'Download Spotify playlists and tracks to offline MP3.', icon: 'fa-brands fa-spotify', type: 'DOWNLOADER', isPremium: true },
  { id: 't5', name: 'FB Video Saver', description: 'Easy downloader for Facebook videos (Private & Public).', icon: 'fa-brands fa-facebook', type: 'DOWNLOADER', isPremium: false },
  { id: 't6', name: 'X/Twitter DL', description: 'Get videos and GIFs from X (Twitter) directly.', icon: 'fa-brands fa-x-twitter', type: 'DOWNLOADER', isPremium: false },
  { id: 't7', name: 'APK Extractor', description: 'Extract and share installed APKs from your device.', icon: 'fa-solid fa-file-apk', type: 'OTHER', isPremium: false },
  { id: 't8', name: 'IP Scanner', description: 'Network scanning tool to identify connected devices.', icon: 'fa-solid fa-network-wired', type: 'SECURITY', isPremium: true },
];

interface ToolsHubProps {
  isDarkMode: boolean;
  isVIP: boolean;
  onAction: () => void;
}

const ToolsHub: React.FC<ToolsHubProps> = ({ isDarkMode, isVIP, onAction }) => {
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);
  const [urlInput, setUrlInput] = useState('');
  const [status, setStatus] = useState<'IDLE' | 'PROCESSING' | 'SUCCESS'>('IDLE');
  const [progress, setProgress] = useState(0);

  const handleProcess = () => {
    if (!urlInput.trim()) return;
    setStatus('PROCESSING');
    setProgress(0);
    
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          return 100;
        }
        return p + Math.floor(Math.random() * 15) + 5;
      });
    }, 200);

    setTimeout(() => {
      setStatus('SUCCESS');
      onAction();
    }, 2500);
  };

  const textColor = isDarkMode ? 'text-white' : 'text-slate-900';
  const cardBg = isDarkMode ? 'bg-slate-900' : 'bg-white';
  const borderColor = isDarkMode ? 'border-slate-800' : 'border-slate-100';

  return (
    <div className={`p-6 pb-32 animate-in fade-in duration-500`}>
      <header className="mb-10">
        <h1 className={`text-3xl font-black italic uppercase tracking-tighter ${textColor}`}>Super Tools Hub</h1>
        <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.3em] mt-2">GitHub Integrated Utilities</p>
      </header>

      {/* Main Tool Processor */}
      {selectedTool && (
        <div className={`mb-10 p-8 rounded-[3rem] border shadow-2xl animate-in slide-in-from-top-6 ${cardBg} ${borderColor}`}>
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center text-white text-2xl shadow-lg">
                <i className={selectedTool.icon}></i>
              </div>
              <div>
                <h2 className={`text-xl font-black italic uppercase ${textColor}`}>{selectedTool.name}</h2>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Powered by Open Source API</p>
              </div>
            </div>
            <button onClick={() => { setSelectedTool(null); setStatus('IDLE'); }} className="text-slate-400"><i className="fa-solid fa-xmark"></i></button>
          </div>

          {selectedTool.isPremium && !isVIP ? (
            <div className="text-center py-6 bg-amber-500/5 rounded-3xl border border-amber-500/10">
               <i className="fa-solid fa-lock text-amber-500 text-3xl mb-3"></i>
               <h4 className="text-sm font-black text-amber-500 uppercase">VIP Feature Only</h4>
               <p className="text-[10px] text-slate-400 mt-1 px-10">Ups, tool ini khusus buat member VIP CHIKIMOD. Upgrade dulu bro!</p>
            </div>
          ) : (
            <div className="space-y-4">
               <div className={`flex items-center gap-4 px-6 py-4 rounded-2xl border ${isDarkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>
                  <i className="fa-solid fa-link text-blue-500"></i>
                  <input 
                    type="text" 
                    placeholder="Tempel link (TikTok, YT, IG) di sini..." 
                    className="bg-transparent flex-1 text-sm focus:outline-none font-medium"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                  />
               </div>
               
               {status === 'PROCESSING' && (
                 <div className="space-y-2">
                    <div className="flex justify-between items-center text-[10px] font-black text-blue-500 uppercase tracking-widest px-1">
                       <span>Fetching Data...</span>
                       <span>{progress}%</span>
                    </div>
                    <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                       <div className="h-full bg-blue-600 transition-all duration-300" style={{ width: `${progress}%` }}></div>
                    </div>
                 </div>
               )}

               {status === 'SUCCESS' && (
                 <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                       <i className="fa-solid fa-circle-check text-emerald-500"></i>
                       <span className="text-xs font-black text-emerald-600 uppercase">Ready for download!</span>
                    </div>
                    <button className="bg-emerald-500 text-white px-6 py-2 rounded-xl text-[10px] font-black uppercase shadow-lg shadow-emerald-500/20">Save File</button>
                 </div>
               )}

               <button 
                onClick={handleProcess}
                disabled={status === 'PROCESSING'}
                className="w-full bg-slate-900 text-white font-black py-4 rounded-2xl shadow-xl shadow-slate-200 active:scale-95 transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-[11px]"
               >
                 <i className="fa-solid fa-bolt-lightning"></i>
                 Generate Download
               </button>
            </div>
          )}
        </div>
      )}

      {/* Tools Grid */}
      <div className="grid grid-cols-2 gap-4">
        {MOCK_TOOLS.map(tool => (
          <div 
            key={tool.id}
            onClick={() => setSelectedTool(tool)}
            className={`p-6 rounded-[2.5rem] border transition-all active:scale-95 cursor-pointer relative group flex flex-col items-center text-center ${cardBg} ${borderColor} hover:border-blue-500/50 hover:shadow-xl`}
          >
            {tool.isPremium && (
              <div className="absolute top-4 right-4 text-amber-500">
                <i className="fa-solid fa-crown text-[10px]"></i>
              </div>
            )}
            <div className={`w-14 h-14 rounded-2xl mb-4 flex items-center justify-center text-2xl transition-all group-hover:scale-110 ${isDarkMode ? 'bg-slate-950 text-blue-400' : 'bg-slate-50 text-blue-600'}`}>
              <i className={tool.icon}></i>
            </div>
            <h3 className={`text-xs font-black uppercase tracking-tight italic mb-2 ${textColor}`}>{tool.name}</h3>
            <p className="text-[9px] text-slate-400 font-medium leading-tight line-clamp-2">{tool.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ToolsHub;
