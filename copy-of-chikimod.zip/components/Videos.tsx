
import React, { useState } from 'react';
import { MOCK_VIDEOS } from '../constants';

interface VideosProps {
  onReport: (id: string, type: 'VIDEO', name: string) => void;
}

const Videos: React.FC<VideosProps> = ({ onReport }) => {
  const [activeCategory, setActiveCategory] = useState<'ALL' | 'TUTORIAL' | 'SHOWCASE'>('ALL');

  const filteredVideos = activeCategory === 'ALL' 
    ? MOCK_VIDEOS 
    : MOCK_VIDEOS.filter(v => v.category === activeCategory || (activeCategory === 'TUTORIAL' && v.category === 'GUIDE'));

  return (
    <div className="h-screen bg-black overflow-y-scroll snap-y snap-mandatory no-scrollbar pb-20">
      {/* Category Tabs */}
      <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 flex gap-4 bg-black/40 backdrop-blur-md px-6 py-2 rounded-full border border-white/10">
        <button 
          onClick={() => setActiveCategory('ALL')}
          className={`text-xs font-bold uppercase tracking-wider ${activeCategory === 'ALL' ? 'text-white' : 'text-white/40'}`}
        >
          Following
        </button>
        <div className="w-px h-3 bg-white/20 self-center"></div>
        <button 
          onClick={() => setActiveCategory('ALL')}
          className={`text-xs font-bold uppercase tracking-wider ${activeCategory === 'ALL' ? 'text-white' : 'text-white/40'}`}
        >
          For You
        </button>
        <div className="w-px h-3 bg-white/20 self-center"></div>
        <button 
          onClick={() => setActiveCategory('TUTORIAL')}
          className={`text-xs font-bold uppercase tracking-wider ${activeCategory === 'TUTORIAL' ? 'text-blue-400' : 'text-white/40'}`}
        >
          Tutorials
        </button>
      </div>

      {filteredVideos.length === 0 ? (
        <div className="h-full flex flex-col items-center justify-center text-white/40">
           <i className="fa-solid fa-video-slash text-4xl mb-4"></i>
           <p>No videos found in this category</p>
        </div>
      ) : (
        filteredVideos.map((video) => (
          <div key={video.id} className="h-full w-full relative snap-start flex items-center justify-center">
            <video 
              src={video.videoUrl} 
              className="h-full w-full object-cover" 
              autoPlay 
              loop 
              muted 
              playsInline
            />
            
            {/* Overlay UI */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/60 pointer-events-none" />
            
            <div className="absolute right-4 bottom-32 flex flex-col gap-6 items-center text-white">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-gray-500 rounded-full border-2 border-white overflow-hidden shadow-lg">
                  <img src={`https://picsum.photos/seed/${video.author}/50`} alt="" />
                </div>
                <div className="w-5 h-5 bg-red-500 rounded-full -mt-2 border-2 border-black flex items-center justify-center text-[10px] font-bold">
                  <i className="fa-solid fa-plus"></i>
                </div>
              </div>
              
              <div className="flex flex-col items-center gap-1">
                <i className="fa-solid fa-heart text-3xl drop-shadow-md text-white"></i>
                <span className="text-xs font-bold drop-shadow-md">{video.likes}</span>
              </div>
              
              <div className="flex flex-col items-center gap-1">
                <i className="fa-solid fa-comment-dots text-3xl drop-shadow-md"></i>
                <span className="text-xs font-bold drop-shadow-md">{video.comments}</span>
              </div>
              
              <div className="flex flex-col items-center gap-1 cursor-pointer" onClick={() => onReport(video.id, 'VIDEO', video.title)}>
                <i className="fa-solid fa-flag text-2xl drop-shadow-md text-white/60 hover:text-red-400 transition-colors"></i>
                <span className="text-[10px] font-bold drop-shadow-md">Report</span>
              </div>
              
              <div className="flex flex-col items-center gap-1">
                <i className="fa-solid fa-share text-3xl drop-shadow-md"></i>
                <span className="text-xs font-bold drop-shadow-md">Share</span>
              </div>

              <div className="w-10 h-10 rounded-full border-2 border-gray-400 p-1 animate-spin-slow">
                <img src="https://picsum.photos/seed/disc/40" className="rounded-full" alt="" />
              </div>
            </div>

            <div className="absolute left-4 bottom-32 text-white max-w-[70%]">
              <div className="flex gap-2 mb-2">
                {video.category === 'TUTORIAL' && (
                  <span className="bg-blue-600/80 backdrop-blur-md text-[9px] font-black uppercase px-2 py-0.5 rounded flex items-center gap-1">
                    <i className="fa-solid fa-graduation-cap"></i> Tutorial
                  </span>
                )}
                {video.category === 'GUIDE' && (
                  <span className="bg-green-600/80 backdrop-blur-md text-[9px] font-black uppercase px-2 py-0.5 rounded flex items-center gap-1">
                    <i className="fa-solid fa-book"></i> Guide
                  </span>
                )}
              </div>
              <h3 className="font-bold text-lg mb-1">@{video.author}</h3>
              <p className="text-sm line-clamp-2 mb-3">{video.title}</p>
              <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-2 rounded-xl text-xs font-bold border border-white/20 hover:bg-white/30 transition-all cursor-pointer">
                <i className="fa-solid fa-download"></i>
                <span>Get Mod App</span>
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default Videos;
