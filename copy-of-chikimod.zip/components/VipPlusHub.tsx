
import React from 'react';
import { User } from '../types';

interface VipPlusHubProps {
  user: User;
  onUpgrade: (type: 'VIP' | 'PLUS') => void;
  isDarkMode: boolean;
}

const VipPlusHub: React.FC<VipPlusHubProps> = ({ user, onUpgrade, isDarkMode }) => {
  const cardBg = isDarkMode ? 'bg-slate-900' : 'bg-white';
  const textColor = isDarkMode ? 'text-white' : 'text-slate-900';

  return (
    <div className={`min-h-screen pb-32 pt-10 px-6 animate-in fade-in duration-500 ${isDarkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
      <header className="mb-10 text-center">
         <h1 className={`text-4xl font-black italic uppercase tracking-tighter ${textColor}`}>Tier Hub</h1>
         <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.3em] mt-2">Premium Experience Cluster</p>
      </header>

      <div className="space-y-8">
         {/* PLUS SECTION */}
         <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-[3rem] blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
            <div className={`relative p-8 rounded-[3rem] border border-white/10 overflow-hidden ${isDarkMode ? 'bg-slate-900/90' : 'bg-white/90'} backdrop-blur-xl`}>
               <div className="flex justify-between items-start mb-6">
                  <div>
                     <span className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-lg italic">PLUX STATUS</span>
                     <h2 className={`text-3xl font-black mt-4 italic uppercase tracking-tighter ${textColor}`}>God Mode</h2>
                  </div>
                  <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-pink-500 rounded-3xl flex items-center justify-center text-white text-3xl shadow-xl">
                     <i className="fa-solid fa-crown"></i>
                  </div>
               </div>
               
               <ul className="space-y-3 mb-8">
                  {[
                    'Akses ke Mod "Private Server"',
                    'Bypass Keamanan Anti-Ban Level 5',
                    'Direct Chat Admin ifgaralviyansah',
                    'Badge Holografik PLUS Eksklusif',
                    'Fitur "God Tools" di Tools Hub'
                  ].map((benefit, i) => (
                    <li key={i} className="flex items-center gap-3 text-xs font-bold text-slate-400">
                       <i className="fa-solid fa-check-circle text-purple-500"></i>
                       {benefit}
                    </li>
                  ))}
               </ul>

               {user.isPLUS ? (
                 <div className="w-full py-5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl flex items-center justify-center gap-3 shadow-xl">
                    <i className="fa-solid fa-sparkles text-white animate-pulse"></i>
                    <span className="text-white font-black uppercase text-xs tracking-widest">PLUX AUTHORIZED</span>
                 </div>
               ) : (
                 <button 
                  onClick={() => onUpgrade('PLUS')}
                  className="w-full py-5 bg-slate-950 text-white rounded-2xl font-black uppercase text-xs tracking-[0.3em] hover:scale-[1.02] active:scale-95 transition-all shadow-2xl"
                 >
                    Upgrade to PLUX
                 </button>
               )}
            </div>
         </div>

         {/* VIP SECTION */}
         <div className={`p-8 rounded-[3rem] border border-amber-500/20 relative overflow-hidden ${cardBg}`}>
            <div className="absolute top-0 right-0 p-6 opacity-5">
               <i className="fa-solid fa-gem text-9xl text-amber-500 rotate-12"></i>
            </div>
            
            <div className="flex justify-between items-start mb-6">
               <div>
                  <span className="bg-amber-500 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-lg italic">VIP STATUS</span>
                  <h2 className={`text-3xl font-black mt-4 italic uppercase tracking-tighter ${textColor}`}>Elite Access</h2>
               </div>
               <div className="w-16 h-16 bg-amber-500 rounded-3xl flex items-center justify-center text-white text-3xl shadow-xl">
                  <i className="fa-solid fa-gem"></i>
               </div>
            </div>

            <ul className="space-y-3 mb-8">
               {[
                 'Download APK Tanpa Iklan',
                 'Request Mod APK Prioritas',
                 'Badge VIP Emas di Global Chat',
                 'Akses ke Store VIP Exclusive'
               ].map((benefit, i) => (
                 <li key={i} className="flex items-center gap-3 text-xs font-bold text-slate-400">
                    <i className="fa-solid fa-check-circle text-amber-500"></i>
                    {benefit}
                 </li>
               ))}
            </ul>

            {user.isVIP || user.isPLUS ? (
              <div className="w-full py-5 bg-amber-500 rounded-2xl flex items-center justify-center gap-3 shadow-xl">
                 <i className="fa-solid fa-circle-check text-white"></i>
                 <span className="text-white font-black uppercase text-xs tracking-widest">VIP AUTHORIZED</span>
              </div>
            ) : (
              <button 
                onClick={() => onUpgrade('VIP')}
                className="w-full py-5 bg-amber-500 text-white rounded-2xl font-black uppercase text-xs tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-xl"
              >
                 Join VIP Member
              </button>
            )}
         </div>

      </div>
    </div>
  );
};

export default VipPlusHub;
