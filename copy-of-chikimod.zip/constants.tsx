
import { Rank, AppData, ForumPost, User, Report, AppRequest } from './types';

export const RANK_CONFIG: Record<Rank, { color: string; bg: string; icon: string }> = {
  [Rank.BRONZE]: { color: '#cd7f32', bg: 'bg-[#cd7f32]', icon: 'fa-solid fa-shield-halved' },
  [Rank.SILVER]: { color: '#c0c0c0', bg: 'bg-[#c0c0c0]', icon: 'fa-solid fa-shield-halved' },
  [Rank.GOLD]: { color: '#ffd700', bg: 'bg-[#ffd700]', icon: 'fa-solid fa-shield-halved' },
  [Rank.PLATINUM]: { color: '#e5e4e2', bg: 'bg-cyan-200', icon: 'fa-solid fa-crown' },
  [Rank.DIAMOND]: { color: '#b9f2ff', bg: 'bg-blue-400', icon: 'fa-solid fa-gem' },
  [Rank.MASTER]: { color: '#9d00ff', bg: 'bg-purple-600', icon: 'fa-solid fa-fire' },
  [Rank.GRANDMASTER]: { color: '#ff0000', bg: 'bg-red-600', icon: 'fa-solid fa-dragon' },
};

const DEFAULT_PRIVACY = {
  showActivity: true,
  privateProfile: false,
  showRank: true,
  publicDownloads: true,
  showSocials: true,
  allowMessages: true,
};

const DEFAULT_NOTIFS = {
  comments: true,
  updates: true,
  system: true,
  messages: true,
  vip: true,
};

const DEFAULT_SOCIALS = {
  instagram: '',
  github: '',
  discord: '',
  twitter: '',
  telegram: '',
};

export const MOCK_APPS: AppData[] = [
  { 
    id: '1', 
    name: 'Spotify Premium', 
    category: 'Music', 
    rating: 4.8, 
    size: '32MB', 
    icon: 'https://upload.wikimedia.org/wikipedia/commons/1/19/Spotify_logo_without_text.svg', 
    isModded: true, 
    downloads: '1.2M', 
    description: 'Unlock the full potential of your music experience with unlimited skips, offline listening, and zero ads.',
    version: '8.9.74.568',
    developer: 'Spotify AB',
    updatedAt: '24 May 2024',
    packageName: 'com.spotify.music.mod',
    minAndroid: 'Android 5.0+',
    screenshots: [
      'https://picsum.photos/seed/spotify1/400/800',
      'https://picsum.photos/seed/spotify2/400/800',
      'https://picsum.photos/seed/spotify3/400/800'
    ],
    modFeatures: ['Unlimited Skips', 'No Audio Ads', 'Canvas Unlocked', 'Select Any Song']
  },
  { 
    id: '2', 
    name: 'Netflix MOD', 
    category: 'Entertainment', 
    rating: 4.5, 
    size: '54MB', 
    icon: 'https://www.edigitalagency.com.au/wp-content/uploads/Netflix-logo-red-black-png.png', 
    isModded: true, 
    downloads: '500K', 
    description: 'Stream your favorite movies and shows in ultra-high definition without any subscription fees.',
    version: '8.112.0',
    developer: 'Netflix Inc.',
    updatedAt: '12 June 2024',
    packageName: 'com.netflix.mediaclient.mod',
    minAndroid: 'Android 7.0+',
    screenshots: [
      'https://picsum.photos/seed/netflix1/400/800',
      'https://picsum.photos/seed/netflix2/400/800'
    ],
    modFeatures: ['No Subscription Required', '4K Ultra HD Streaming', 'Offline Download Enabled']
  },
  { 
    id: '3', 
    name: 'Free Fire Ultra', 
    category: 'Action', 
    rating: 4.9, 
    size: '1.2GB', 
    icon: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS80R7fFz3Z1V9oXw6fSg_U-jVl6qKxY6qKxQ&s', 
    isModded: true, 
    downloads: '5M', 
    description: 'Experience the ultimate survival shooter with unlocked skins, enhanced graphics, and anti-ban protection.',
    version: '1.104.1',
    developer: 'Garena International',
    updatedAt: '05 June 2024',
    packageName: 'com.dts.freefireth.mod',
    minAndroid: 'Android 4.4+',
    screenshots: [
      'https://picsum.photos/seed/ff1/400/800',
      'https://picsum.photos/seed/ff2/400/800',
      'https://picsum.photos/seed/ff3/400/800'
    ],
    modFeatures: ['Wallhack (ESP)', 'Auto Aim Assist', 'Unlocked All Skins', 'High Damage']
  }
];

export const MOCK_USERS: User[] = [
  { 
    id: 'u1', 
    name: 'Admin Chiki', 
    nickname: 'Shadow Dev',
    email: 'ifgaralviyansah71@gmail.com', 
    rank: Rank.GRANDMASTER, 
    points: 9999, 
    isVIP: true, 
    isPLUS: true, 
    avatar: 'https://picsum.photos/seed/admin/100', 
    banner: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=1000',
    isAdmin: true, 
    privacy: DEFAULT_PRIVACY,
    notificationPreferences: DEFAULT_NOTIFS,
    socials: { ...DEFAULT_SOCIALS, github: 'chikimod-official', instagram: 'chikimod' },
    bio: 'CHIKIMOD Founder & Developer. Kalo ada bug lapor aja ke gue. Santai aja bro.',
    status: 'online',
    customStatus: 'Coding for the future of mods',
    location: 'Jakarta, Indonesia',
    gender: 'Robot',
    birthday: '2024-01-01',
    tag: '0001',
    streakCount: 5,
    lastActiveDate: new Date().toISOString().split('T')[0],
    coupleFlowerLevel: 85,
    partnerId: 'u2',
    partnerName: 'Andi Gaming'
  },
  { 
    id: 'u2', 
    name: 'Andi Gaming', 
    nickname: 'ProModder',
    email: 'andi@chikimod.com', 
    rank: Rank.BRONZE, 
    points: 0, 
    isVIP: false, 
    isPLUS: false, 
    avatar: 'https://picsum.photos/seed/user2/100', 
    banner: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=1000',
    isAdmin: false, 
    privacy: DEFAULT_PRIVACY,
    notificationPreferences: DEFAULT_NOTIFS,
    socials: DEFAULT_SOCIALS,
    bio: 'Pecinta mod game.',
    status: 'online',
    tag: '4231',
    streakCount: 0,
    lastActiveDate: new Date().toISOString().split('T')[0],
    coupleFlowerLevel: 0,
  },
];

// Added missing MOCK_POSTS for Community module
export const MOCK_POSTS: ForumPost[] = [
  {
    id: 'p1',
    userId: 'u1',
    userName: 'Admin Chiki',
    userRank: Rank.GRANDMASTER,
    content: 'Selamat datang di cluster CHIKIMOD! Jangan lupa buat patuhi protokol komunitas kita ya.',
    timestamp: '2 hours ago',
    likes: 42,
    comments: 1,
    commentList: [
      { id: 'c1', userId: 'u2', userName: 'Andi Gaming', userRank: Rank.BRONZE, avatar: 'https://picsum.photos/seed/user2/100', text: 'Siap admin!', timestamp: '1 hour ago' }
    ]
  }
];

// Added missing MOCK_REPORTS for Admin module
export const MOCK_REPORTS: Report[] = [
  {
    id: 'r1',
    reporterId: 'u2',
    targetId: 'p1',
    targetType: 'POST',
    targetName: 'Admin welcome post',
    reason: 'Test signal reporting',
    timestamp: 'Just now',
    status: 'PENDING'
  }
];

// Added missing MOCK_VIDEOS for Shorts module
export const MOCK_VIDEOS = [
  {
    id: 'v1',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-gaming-setup-with-neon-lights-40156-large.mp4',
    author: 'ModMaster',
    title: 'How to install CHIKIMOD App',
    likes: '12K',
    comments: '400',
    category: 'TUTORIAL'
  },
  {
    id: 'v2',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hand-holding-a-smartphone-with-a-blue-screen-31512-large.mp4',
    author: 'ShadowDev',
    title: 'New Spotify Premium Mod Showcase',
    likes: '8K',
    comments: '120',
    category: 'SHOWCASE'
  }
];

// Added missing MOCK_REQUESTS for VIP module
export const MOCK_REQUESTS: AppRequest[] = [
  { id: 'req1', appName: 'Adobe Lightroom', version: 'Latest', status: 'PENDING', timestamp: '2 days ago' },
  { id: 'req2', appName: 'Kinemaster Pro', version: '6.4.1', status: 'DONE', timestamp: '1 week ago' }
];
