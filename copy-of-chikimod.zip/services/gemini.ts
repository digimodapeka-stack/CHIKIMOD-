
import { GoogleGenAI } from "@google/genai";

// Fix: Updated to follow @google/genai SDK guidelines for client initialization and text extraction.
export const chatWithAI = async (message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  // Always initialize with a named parameter for apiKey.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history,
        { role: 'user', parts: [{ text: message }] }
      ] as any,
      config: {
        systemInstruction: `Lo adalah ChikiAI, temen deket user di platform CHIKIMOD. 
        Gaya bahasa lo harus gaul, santai, dan kayak temen tongkrongan. 
        Gunakan kata 'gue' dan 'lo'. Jangan kaku, jangan formal. 
        Tugas lo bantu user soal mod apps, sistem rank (Bronze-Grandmaster), atau info forum.
        PENTING: Jangan pake banyak emoji, satu atau dua aja cukup kalau perlu banget. 
        Kalo gak tau, bilang aja jujur tapi tetep asik. 
        Inget, lo itu temen, bukan asisten kaku robot. 
        Fokus ke solusi tapi pembawaannya rileks banget.`,
      }
    });
    
    // Direct access to response.text (it's a getter, not a method).
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Aduh, otak gue lagi nge-hang nih. Cek koneksi atau API key lo dulu deh, bro.";
  }
};
