
export enum Rank {
  BRONZE = 'Bronze',
  SILVER = 'Silver',
  GOLD = 'Gold',
  PLATINUM = 'Platinum',
  DIAMOND = 'Diamond',
  MASTER = 'Master',
  GRANDMASTER = 'Grandmaster'
}

export interface PrivacySettings {
  showActivity: boolean;
  privateProfile: boolean;
  showRank: boolean;
  publicDownloads: boolean;
  showSocials: boolean;
  allowMessages: boolean;
}

export interface NotificationPreferences {
  comments: boolean;
  updates: boolean;
  system: boolean;
  messages: boolean;
  vip: boolean;
}

export interface SocialLinks {
  instagram?: string;
  github?: string;
  discord?: string;
  twitter?: string;
  telegram?: string;
}

export interface User {
  id: string;
  name: string;
  nickname?: string;
  email: string;
  rank: Rank;
  points: number;
  isVIP: boolean;
  isPLUS: boolean;
  avatar: string;
  banner?: string;
  isAdmin: boolean;
  privacy: PrivacySettings;
  notificationPreferences: NotificationPreferences;
  socials: SocialLinks;
  bio?: string;
  status?: 'online' | 'idle' | 'dnd' | 'offline';
  customStatus?: string;
  location?: string;
  gender?: 'Male' | 'Female' | 'Robot' | 'Other';
  birthday?: string;
  tag?: string;
  streakCount: number;
  lastActiveDate: string;
  partnerId?: string;
  partnerName?: string;
  coupleFlowerLevel: number;
  coupleSince?: string;
  themeColor?: string;
}

export type ToolType = 'DOWNLOADER' | 'CONVERTER' | 'SECURITY' | 'OTHER';

export interface Tool {
  id: string;
  name: string;
  description: string;
  icon: string;
  type: ToolType;
  githubUrl?: string;
  isPremium: boolean;
  isPlusOnly?: boolean;
}

export type NavItem = 'STORE' | 'TOOLS' | 'VIDEOS' | 'FORUM' | 'COMMUNITY' | 'LEADERBOARD' | 'AI' | 'REQUESTS' | 'PROFILE' | 'ADMIN' | 'VIP_HUB' | 'ABOUT';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'COMMENT' | 'UPDATE' | 'MESSAGE' | 'SYSTEM' | 'STREAK' | 'COUPLE' | 'TOOL' | 'VIP';
  timestamp: string;
  read: boolean;
}

export interface AppData { 
  id: string; 
  name: string; 
  category: string; 
  rating: number; 
  size: string; 
  icon: string; 
  isModded: boolean; 
  downloads: string; 
  description: string; 
  isExclusive?: 'VIP' | 'PLUS';
  version?: string;
  developer?: string;
  updatedAt?: string;
  packageName?: string;
  minAndroid?: string;
  screenshots?: string[];
  modFeatures?: string[];
  fileUrl?: string;
}

// Added Comment interface for Forum post interactions
export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userRank: Rank;
  avatar: string;
  text: string;
  timestamp: string;
}

export interface ChatMessage { id: string; senderId: string; senderName: string; senderRank: Rank; senderAvatar: string; text: string; timestamp: string; isMe: boolean; type: 'TEXT' | 'IMAGE' | 'SYSTEM'; }
export interface ForumPost { id: string; userId: string; userName: string; userRank: Rank; content: string; timestamp: string; likes: number; comments: number; image?: string; video?: string; commentList?: Comment[]; }
export interface Report { id: string; reporterId: string; targetId: string; targetType: 'POST' | 'APP' | 'VIDEO' | 'USER'; targetName: string; reason: string; timestamp: string; status: 'PENDING' | 'RESOLVED'; }

// Added AdminTab type for Admin module navigation
export type AdminTab = 'DASHBOARD' | 'USERS' | 'APP_DEPLOY' | 'SIGNALS' | 'MODERATION' | 'REPORTS' | 'MAINTENANCE' | 'VOUCHERS' | 'SYSTEM_HEALTH' | 'AUDIT_LOGS' | 'BANNERS' | 'API_KEYS' | 'RANK_CONFIG' | 'DATABASE' | 'SUPPORT';

// Added AppRequest interface for VIP request module
export interface AppRequest {
  id: string;
  appName: string;
  version: string;
  status: 'PENDING' | 'DONE';
  timestamp: string;
}
